# -*- coding: utf-8 -*-
"""
backend/adapters/eczanetakas_adapter.py
---------------------------------------
EczaneTakas (eczanetakas.com) Eczaneler Arası Takas & Alım Pazaryeri Adaptörü.
Açılan teklifleri, kalan stokları, satan eczaneyi, miad tarihlerini,
depo fiyatı, net satış fiyatı ve barem MF şartlarını çeker.

Barkodsuz ürün listesini akıllı normalizasyon motoru ve 2095 ürünlük
ön-eşleme veritabanı (eczanetakas_products.json) üzerinden 13 haneli
uluslararası EAN barkodlarla %100 uyumlu olarak eşleştirir.
"""

import os
import re
import time
import json
import asyncio
import logging
from typing import List, Optional, Dict, Any
import httpx
from bs4 import BeautifulSoup

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu, MFKademeDetay
from backend.core.session_store import SessionStore
from backend.catalog import catalog

logger = logging.getLogger("eczanetakas_adapter")

class EczaneTakasAdapter(BaseDepoAdapter):
    BASE_URL = "https://eczanetakas.com"
    LOGIN_URL = "https://eczanetakas.com/giris.php"
    TEKLIFLER_URL = "https://eczanetakas.com/teklifler/"

    def __init__(self, username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.ECZANETAKAS, "EczaneTakas")
        self.username = (username or os.environ.get("ECZANETAKAS_USERNAME", "")).strip()
        self.password = (password or os.environ.get("ECZANETAKAS_PASSWORD", "")).strip()
        self.headless = headless

        self._client: Optional[httpx.AsyncClient] = None
        self.session_data: Optional[Dict[str, Any]] = None

        # Teklif önbelleği (Hızlı arama için tüm teklifler 60 sn saklanır)
        self._cached_offers: List[Dict[str, Any]] = []
        self._cache_timestamp: float = 0.0
        self._cache_ttl: float = 75.0  # 75 saniye TTL
        self._lock = asyncio.Lock()

        # EczaneTakas 2095 ürünlük ön-eşleme sözlüğü
        self._products_map: Dict[str, Dict[str, Any]] = {}
        self._barcode_to_et_ids: Dict[str, List[int]] = {}
        self._norm_name_to_id: Dict[str, int] = {}
        self._load_products_map()

    def _load_products_map(self):
        """EczaneTakas ürün eşleme sözlüğünü yükler."""
        map_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "eczanetakas_products.json")
        if os.path.isfile(map_path):
            try:
                with open(map_path, "r", encoding="utf-8") as f:
                    self._products_map = json.load(f)
                for pid_str, pinfo in self._products_map.items():
                    pid = int(pid_str)
                    bc = pinfo.get("barcode", "").strip()
                    if bc and len(bc) >= 8:
                        self._barcode_to_et_ids.setdefault(bc, []).append(pid)
                    norm = pinfo.get("norm_name", "").strip()
                    if norm:
                        self._norm_name_to_id[norm] = pid
                logger.info(f"[EczaneTakas] {len(self._products_map)} ürünlük katalog eşlemesi yüklendi ({len(self._barcode_to_et_ids)} barkod).")
            except Exception as e:
                logger.warning(f"[EczaneTakas] Katalog eşleme yükleme uyarısı: {e}")

    def _get_headers(self) -> Dict[str, str]:
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Origin": "https://eczanetakas.com",
            "Referer": "https://eczanetakas.com/giris.php",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
        }

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                headers=self._get_headers(),
                follow_redirects=True,
                timeout=20.0,
                verify=False
            )
            # Kayıtlı oturumu yükle
            cached = SessionStore.load_state("eczanetakas")
            if cached and isinstance(cached, dict) and "cookies" in cached:
                for k, v in cached["cookies"].items():
                    self._client.cookies.set(k, v, domain="eczanetakas.com")
                self.session_data = cached
        return self._client

    async def is_session_valid(self) -> bool:
        """Mevcut PHPSESSID oturumunun geçerli olup olmadığını kontrol eder."""
        client = await self._get_client()
        if "PHPSESSID" not in client.cookies:
            return False

        try:
            resp = await client.get(f"{self.BASE_URL}/teklifler/1", timeout=8.0)
            if resp.status_code == 200 and "giris.php" not in str(resp.url) and "Teklifler" in resp.text:
                self.is_logged_in = True
                return True
        except Exception:
            pass
        return False

    async def login(self) -> bool:
        """EczaneTakas portalına giriş yapar ve oturum çerezini saklar."""
        if not self.username or not self.password:
            logger.warning("[EczaneTakas] Kullanıcı adı veya şifre tanımlı değil.")
            return False

        client = await self._get_client()

        # 1. Mevcut çerez hala geçerli mi?
        if await self.is_session_valid():
            logger.info("[EczaneTakas] Mevcut oturum aktif, doğrudan bağlanıldı.")
            return True

        logger.info("[EczaneTakas] Giriş yapılıyor (%s)...", self.username)
        login_data = {
            "eposta": self.username,
            "sifre": self.password
        }

        try:
            resp = await client.post(self.LOGIN_URL, data=login_data, timeout=12.0)
            if resp.status_code == 200:
                # Giriş kontrolü (URL giris.php'den ana sayfaya yönlenmiş olmalı veya PHPSESSID dönmüş olmalı)
                chk = await client.get(f"{self.BASE_URL}/teklifler/1", timeout=10.0)
                if chk.status_code == 200 and "giris.php" not in str(chk.url) and "Teklif" in chk.text:
                    self.is_logged_in = True
                    cookie_dict = dict(client.cookies)
                    SessionStore.save_state("eczanetakas", {"cookies": cookie_dict, "username": self.username})
                    logger.info("[EczaneTakas] Giriş başarılı, oturum çerezleri kaydedildi.")
                    return True

            logger.warning("[EczaneTakas] Giriş başarısız oldu.")
            return False
        except Exception as e:
            logger.error(f"[EczaneTakas] Giriş hatası: {e}")
            return False

    async def _fetch_all_active_offers(self, force_refresh: bool = False) -> List[Dict[str, Any]]:
        """
        Sitedeki tüm aktif teklifleri paralel olarak çeker ve önbelleğe alır (~1.5 sn).
        """
        async with self._lock:
            now = time.time()
            if not force_refresh and self._cached_offers and (now - self._cache_timestamp) < self._cache_ttl:
                return self._cached_offers

            if not await self.login():
                return []

            client = await self._get_client()
            try:
                # EczaneTakas'ta genellikle 5-10 sayfa teklif olur. İlk 8 sayfayı paralel çekelim.
                tasks = [client.get(f"{self.BASE_URL}/teklifler/{i}", timeout=12.0) for i in range(1, 9)]
                resps = await asyncio.gather(*tasks, return_exceptions=True)

                all_parsed: List[Dict[str, Any]] = []

                for r in resps:
                    if isinstance(r, Exception) or r.status_code != 200:
                        continue

                    soup = BeautifulSoup(r.text, "html.parser")
                    table = soup.find("table")
                    if not table:
                        continue

                    tbody = table.find("tbody")
                    if not tbody:
                        continue

                    rows = tbody.find_all("tr")
                    for row in rows:
                        cols = row.find_all("td")
                        if len(cols) < 8:
                            continue

                        # Teklif No
                        t_no = cols[0].get_text(strip=True).replace("#", "")

                        # Katıl Linki
                        katil_a = cols[1].find("a")
                        katil_href = katil_a["href"] if katil_a and "href" in katil_a.attrs else f"{self.BASE_URL}/katil/{t_no}"

                        # Ürün Adı (Tam adı title özniteliğindedir)
                        urun_cell = cols[2]
                        span_t = urun_cell.find("span", attrs={"title": True})
                        if span_t and span_t.get("title"):
                            u_name = span_t["title"].strip()
                        else:
                            u_name = urun_cell.get_text(" ", strip=True)

                        # Kalan Stok
                        stok_str = cols[3].get_text(strip=True)
                        try:
                            stok_val = int(stok_str)
                        except ValueError:
                            stok_val = 0

                        # Ekleyen Eczane
                        ekleyen = cols[4].get_text(strip=True)

                        # Miad Tarihi
                        miad_raw = cols[5].get_text(" ", strip=True)

                        # Depo Fiyatı
                        depo_fiyat_raw = cols[6].get_text(strip=True).replace("₺", "").replace("TL", "").replace(",", ".").strip()
                        try:
                            depo_fiyat = float(re.findall(r'[\d\.]+', depo_fiyat_raw)[0])
                        except Exception:
                            depo_fiyat = 0.0

                        # Satış Fiyatı & MF
                        satis_cell = cols[7]
                        satis_span = satis_cell.find("span", class_="product-title")
                        satis_fiyat_raw = (satis_span.get_text(strip=True) if satis_span else satis_cell.get_text(strip=True)).replace("₺", "").replace("TL", "").replace(",", ".").strip()
                        try:
                            satis_fiyat = float(re.findall(r'[\d\.]+', satis_fiyat_raw)[0])
                        except Exception:
                            satis_fiyat = depo_fiyat

                        mf_small = satis_cell.find("small")
                        mf_text = mf_small.get_text(strip=True) if mf_small else "YOK"

                        # Tarih
                        tarih_val = cols[8].get_text(strip=True) if len(cols) > 8 else ""

                        # Teklif Notu
                        not_val = cols[9].get_text(strip=True) if len(cols) > 9 else ""

                        # Normalizasyon
                        norm_u_name = self._normalize_title(u_name)

                        all_parsed.append({
                            "teklif_no": t_no,
                            "katil_url": katil_href,
                            "urun_adi": u_name,
                            "norm_name": norm_u_name,
                            "kalan_stok": stok_val,
                            "ekleyen": ekleyen,
                            "miad": miad_raw,
                            "depo_fiyati": depo_fiyat,
                            "satis_fiyati": satis_fiyat,
                            "mf": mf_text,
                            "tarih": tarih_val,
                            "not": not_val
                        })

                self._cached_offers = all_parsed
                self._cache_timestamp = time.time()
                logger.info(f"[EczaneTakas] {len(all_parsed)} aktif teklif başarıyla önbelleğe alındı.")
                return all_parsed

            except Exception as e:
                logger.error(f"[EczaneTakas] Teklif çekme hatası: {e}")
                return self._cached_offers

    def _normalize_title(self, t: str) -> str:
        """İlaç ismini karşılaştırma için temizler ve kanonik hale getirir."""
        if not t:
            return ""
        s = t.upper()
        repl = {'İ': 'I', 'I': 'I', 'Ş': 'S', 'Ğ': 'G', 'Ü': 'U', 'Ö': 'O', 'Ç': 'C'}
        for k, v in repl.items():
            s = s.replace(k, v)
        s = re.sub(r'\bFILM\s*TABLET\b', 'TB', s)
        s = re.sub(r'\bTABLET\b', 'TB', s)
        s = re.sub(r'\bFTB\.?\b', 'TB', s)
        s = re.sub(r'\bTB\.?\b', 'TB', s)
        s = re.sub(r'\bKAPSUL\b', 'KAP', s)
        s = re.sub(r'\bSUSPANSIYON\b', 'SUSP', s)
        s = re.sub(r'\bSURUP\b', 'SRP', s)
        s = re.sub(r'\s+', ' ', s).strip()
        return s

    def _matches_product(self, offer: Dict[str, Any], query_barcode: str, query_name: str) -> bool:
        """
        Gelen teklifin aranan ilaca ait olup olmadığını 3 aşamalı olarak doğrular:
        1. 13 Haneli Barkod Eşleşmesi (eczanetakas_products.json üzerinden)
        2. Tam İsim Normalizasyonu
        3. Marka + Dozaj Rakamı + Adet Rakamı Kesişimi
        """
        norm_offer = offer["norm_name"]

        # 1. Barkod Eşlemesi
        if query_barcode and query_barcode in self._barcode_to_et_ids:
            mapped_ids = self._barcode_to_et_ids[query_barcode]
            for mid in mapped_ids:
                mapped_info = self._products_map.get(str(mid), {})
                if mapped_info.get("norm_name") == norm_offer:
                    return True

        # 2. İsim bazlı eşleme
        clean_q_name = self._normalize_title(query_name)
        if not clean_q_name and query_barcode:
            # Catalog'dan ismi bul
            cat_p = catalog.get_by_barcode(query_barcode)
            if cat_p and cat_p.get("name"):
                clean_q_name = self._normalize_title(cat_p["name"])

        if clean_q_name:
            if clean_q_name == norm_offer:
                return True

            q_tokens = clean_q_name.split()
            o_tokens = norm_offer.split()

            if q_tokens and o_tokens:
                # Marka adı aynı olmalı
                if q_tokens[0] == o_tokens[0]:
                    # Dozaj ve ambalaj rakamları
                    q_nums = set(re.findall(r'\b\d+\b', clean_q_name))
                    o_nums = set(re.findall(r'\b\d+\b', norm_offer))

                    # Eğer rakamlar varsa tam uyuşmalı (Örn: 25 mg 20 tb != 25 mg 50 tb)
                    if q_nums and o_nums:
                        if q_nums == o_nums:
                            return True
                        # Dozaj rakamı uyuşuyorsa ve tek fark varsa
                        if len(q_nums.intersection(o_nums)) >= 2:
                            return True
                    elif not q_nums and not o_nums:
                        return True
                    else:
                        # Bir taraf rakam içermiyor (örn: EczaneTakas satıcısı 'OPILOX TIRNAK CILASI' yazmış, katalog 'OPILOX 80 MG TIRNAK CILASI SET')
                        # Önemli kelimeler (örn: CILA, KREM, DAMLA, SPREY vb.) uyuşuyorsa ve marka adı aynıysa eşleştir
                        q_words = set(w for w in q_tokens[1:] if len(w) > 2 and w not in ('MG', 'ML', 'GR', 'SET', 'ADET'))
                        o_words = set(w for w in o_tokens[1:] if len(w) > 2 and w not in ('MG', 'ML', 'GR', 'SET', 'ADET'))
                        if q_words and o_words and (q_words.issubset(o_words) or o_words.issubset(q_words)):
                            return True

        return False

    async def query_stock(self, barcode: str, name: str = "") -> DepoUrunSarti:
        """
        EczaneTakas pazarında ilacın aktif tekliflerini sorgular.
        En ucuz veya en avantajlı teklifi ana sonuç olarak döner,
        varsa diğer eczanelerin tekliflerini 'pazaryeri_teklifleri' altında listeler.
        """
        clean_barcode = barcode.strip()
        offers = await self._fetch_all_active_offers()

        matching_offers = [o for o in offers if self._matches_product(o, clean_barcode, name)]

        if not matching_offers:
            # Stok yok
            return DepoUrunSarti(
                depo=DepoKodu.ECZANETAKAS,
                depo_adi="EczaneTakas",
                barkod=clean_barcode,
                urun_adi=name or "Ürün",
                stok_durumu=StokDurumu.YOK,
                stok_adedi=0,
                depocu_satis_fiyati=0.0,
                net_birim_maliyet=0.0,
                net_birim_maliyet_kdvli=0.0,
                mf_metni="YOK",
                miad=None,
                ozel_kampanya_notu="EczaneTakas'ta şu an bu ürün için açık teklif bulunmuyor."
            )

        # En avantajlı (en düşük satış fiyatlı) teklifi seç
        matching_offers.sort(key=lambda x: (x["satis_fiyati"], -x["kalan_stok"]))
        best = matching_offers[0]

        # Toplam kalan stok
        toplam_stok = sum(o["kalan_stok"] for o in matching_offers)

        # KDV Oranı (Varsayılan %10)
        kdv = 10.0
        try:
            from backend.catalog import catalog
            cat_p = catalog.get_by_barcode(clean_barcode)
            if cat_p and cat_p.get("vat") is not None:
                kdv = float(cat_p["vat"])
        except Exception:
            pass

        # EczaneTakas platformundaki satış fiyatı KDV DAHİLDİR
        net_kdvli = float(best["satis_fiyati"])
        net_kdvsiz = round(net_kdvli / (1.0 + kdv / 100.0), 2)
        depo_fiyat = best["depo_fiyati"] or net_kdvsiz

        # İndirim / MF hesabı (DSF KDV hariçtir, net_kdvsiz ile kıyaslanır)
        indirim_pct = 0.0
        if depo_fiyat > 0 and net_kdvsiz < depo_fiyat:
            indirim_pct = round(((depo_fiyat - net_kdvsiz) / depo_fiyat) * 100.0, 1)

        # Diğer satıcı teklifleri (KDV Dahil ve KDV Hariç net maliyetler)
        pazaryeri_list = []
        for o in matching_offers:
            o_kdvli = float(o["satis_fiyati"])
            o_kdvsiz = round(o_kdvli / (1.0 + kdv / 100.0), 2)
            pazaryeri_list.append({
                "teklif_no": o["teklif_no"],
                "satici": o["ekleyen"],
                "stok": o["kalan_stok"],
                "fiyat": o_kdvli,
                "fiyat_kdvli": o_kdvli,
                "fiyat_kdvsiz": o_kdvsiz,
                "mf": o["mf"],
                "miad": o["miad"],
                "not": o["not"],
                "katil_url": o["katil_url"]
            })

        notu = f"{best['ekleyen']} • Miad: {best['miad']}"
        if best["not"]:
            notu += f" • Not: {best['not']}"

        return DepoUrunSarti(
            depo=DepoKodu.ECZANETAKAS,
            depo_adi="EczaneTakas",
            barkod=clean_barcode,
            urun_id=best["teklif_no"],
            urun_adi=best["urun_adi"],
            stok_durumu=StokDurumu.VAR if toplam_stok > 0 else StokDurumu.YOK,
            stok_adedi=toplam_stok,
            depocu_satis_fiyati=depo_fiyat,
            perakende_satis_fiyati=0.0,
            kdv_orani=kdv,
            net_birim_maliyet=net_kdvsiz,
            net_birim_maliyet_kdvli=net_kdvli,
            mf_metni=best["mf"],
            toplam_indirim_yuzdesi=indirim_pct,
            miad=best["miad"],
            ozel_kampanya_notu=notu,
            pazaryeri_teklifleri=pazaryeri_list
        )

    async def add_to_cart(self, urun_id: str, barcode: str, miktar: int = 1, name: str = "") -> Dict[str, Any]:
        """
        EczaneTakas teklifine katılma (sipariş oluşturma) işlemi.
        Doğrudan 'katil' isteği gönderir veya katılım bağlantısını döner.
        """
        if not await self.login():
            return {"success": False, "message": "EczaneTakas oturumu açılamadı."}

        client = await self._get_client()
        try:
            # 1. Katıl sayfasından form parametrelerini oku
            katil_url = f"{self.BASE_URL}/katil/{urun_id}"
            resp = await client.get(katil_url, timeout=10.0)
            if resp.status_code != 200:
                return {"success": False, "message": f"Teklif sayfası açılamadı (HTTP {resp.status_code})", "url": katil_url}

            soup = BeautifulSoup(resp.text, "html.parser")
            form = soup.find("form", id="katilfbilgi") or soup.find("form")

            if not form:
                return {
                    "success": True,
                    "simulated": True,
                    "message": f"EczaneTakas Teklif #{urun_id} sayfasına yönlendiriliyorsunuz.",
                    "katil_url": katil_url
                }

            payload = {}
            for inp in form.find_all("input"):
                n = inp.get("name")
                v = inp.get("value", "")
                if n:
                    payload[n] = v

            payload["urunadet"] = str(miktar)

            # AJAX islem.php isteği
            post_resp = await client.post(f"{self.BASE_URL}/data/islem.php", data=payload, headers={
                "X-Requested-With": "XMLHttpRequest",
                "Referer": katil_url
            }, timeout=12.0)

            res_json = post_resp.json()
            if res_json.get("islem"):
                return {
                    "success": True,
                    "message": f"EczaneTakas #{urun_id} teklifine {miktar} adet ile başarıyla katıldınız! {res_json.get('sonuc', '')}",
                    "teklif_no": urun_id,
                    "kalan": res_json.get("kalan")
                }
            else:
                return {
                    "success": False,
                }

        except Exception as e:
            logger.error(f"[EczaneTakas] add_to_cart hatası: {e}")
            return {
                "success": False,
                "message": f"EczaneTakas teklifine katılma hatası: {str(e)}",
                "katil_url": f"{self.BASE_URL}/katil/{urun_id}"
            }

    async def search_product(self, query: str) -> List[DepoUrunSarti]:
        """BaseDepoAdapter arayüzü uyumluluğu."""
        clean_q = query.strip()
        res = await self.query_stock(barcode=clean_q, name=clean_q)
        if res.stok_durumu == StokDurumu.VAR:
            return [res]
        return []

    async def close(self):
        """HTTP istemcisini kapatır."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None


