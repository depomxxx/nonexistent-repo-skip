import asyncio
import json
import re
from typing import List, Optional, Dict, Any
from pathlib import Path
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu
from backend.core.cost_calculator import CostCalculator
from backend.core.session_store import SessionStore

class BekAdapter(BaseDepoAdapter):
    PORTAL_URL = "https://esube.bek.org.tr/"
    FRAMEWORK_URL = "https://esube.bek.org.tr/FrameWorkT1/"

    def __init__(self, username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.BEK, "Bursa Eczacılar Kooperatifi (BEK)")
        self.username = username
        self.password = password
        self.headless = headless
        
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None

    async def _init_browser(self):
        if not self._playwright:
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                args=["--no-sandbox", "--disable-setuid-sandbox"]
            )
            
            session_file = SessionStore.get_session_file("bek")
            if session_file.exists():
                try:
                    self._context = await self._browser.new_context(storage_state=str(session_file))
                except Exception:
                    self._context = await self._browser.new_context()
            else:
                self._context = await self._browser.new_context()
                
            self._page = await self._context.new_page()

    async def is_session_valid(self) -> bool:
        if not self._page:
            await self._init_browser()
            
        try:
            await self._page.goto(self.FRAMEWORK_URL, wait_until="commit", timeout=15000)
            await self._page.wait_for_selector("input[placeholder*='Barkod'], #input-99", timeout=5000)
            return True
        except Exception:
            return False

    async def login(self) -> bool:
        """BEK Portalına giriş yapar."""
        if not self.username or not self.password:
            raise ValueError("BEK için Kullanıcı Adı ve Şifre zorunludur.")

        await self._init_browser()
        
        if await self.is_session_valid():
            print("[BEK] Mevcut oturum aktif, doğrudan bağlanıldı.")
            self.is_logged_in = True
            return True

        print("[BEK] Giriş yapılıyor...")
        await self._page.goto(self.PORTAL_URL, wait_until="domcontentloaded", timeout=20000)

        await self._page.fill("#logonuidfield", str(self.username))
        await self._page.fill("#logonpassfield", str(self.password))
        await self._page.click('input[name="login"]')
        
        await self._page.wait_for_load_state("domcontentloaded")
        await asyncio.sleep(4)

        if "irj/portal" not in self._page.url:
            raise RuntimeError("BEK Giriş Başarısız! Kullanıcı adı veya şifreyi kontrol edin.")

        session_file = SessionStore.get_session_file("bek")
        await self._context.storage_state(path=str(session_file))
        print("[BEK] Başarıyla giriş yapıldı ve oturum kaydedildi.")
        self.is_logged_in = True
        return True

    async def _ensure_ready_page(self):
        if not self._page:
            await self._init_browser()
        if "FrameWorkT1" not in self._page.url:
            await self._page.goto(self.FRAMEWORK_URL, wait_until="domcontentloaded", timeout=15000)

    async def search_product(self, query: str) -> List[DepoUrunSarti]:
        """BEK'te ürün ara ve şartları getir."""
        if not self.is_logged_in:
            await self.login()

        await self._ensure_ready_page()
        print(f"[BEK] '{query}' sorgulanıyor...")

        captured_ms = {}
        async def on_response(res):
            if "mat/ms" in res.url:
                try:
                    captured_ms["data"] = await res.json()
                except Exception:
                    pass

        self._page.on("response", on_response)

        try:
            search_input = await self._page.wait_for_selector('input[placeholder*="Barkod"], #input-99', timeout=8000)
            await search_input.fill(query)
            await search_input.press("Enter")

            # mat/ms yanıtını bekle (azami 5 sn)
            for _ in range(12):
                await asyncio.sleep(0.4)
                if "data" in captured_ms:
                    break

            if "data" not in captured_ms:
                return []

            detail = captured_ms["data"]
            return self._parse_bek_detail(detail, query)
        except Exception as e:
            print(f"[BEK] Arama hatası: {e}")
            return []
        finally:
            try:
                self._page.remove_listener("response", on_response)
            except Exception:
                pass

    def _parse_bek_detail(self, detail: Dict[str, Any], query: str) -> List[DepoUrunSarti]:
        mat_kart = detail.get("EP_S_MALZEME_KARTI") or {}
        vwerk = detail.get("EP_S_VWERK") or {}
        baremler = detail.get("EP_T_BAREM") or []
        klasm = detail.get("EP_T_KLASM") or []

        ad = mat_kart.get("MAKTX", "")
        if not ad:
            return []

        barkod = mat_kart.get("BARKOD") or query
        matnr = mat_kart.get("MATNR", "")

        psf = float(mat_kart.get("PSF") or 0.0)
        dsf = float(mat_kart.get("DSF") or 0.0)
        if dsf == 0.0 and psf > 0:
            dsf = round(psf * 0.7102, 2)
        kdv_orani = float(mat_kart.get("KDV") or 10.0)

        # Stok durumu
        stok_mevcut = vwerk.get("STOK_MEVCUT") or ""
        stok_durumu = StokDurumu.VAR if stok_mevcut in ["T", "X", "1", "Var"] else StokDurumu.YOK

        if not klasm:
            klasm = [{"KLASM": "030", "VADE_ADI": "30 Gün", "DSF": dsf, "NETFIYAT": dsf, "ZTC1": 0.0}]

        sonuclar: List[DepoUrunSarti] = []

        # Her bir ödeme seçeneğini (KLASM) ayrı bir şart olarak değerlendir (90 Gün Vade & Kredi Kartı)
        for k in klasm:
            k_klasm = str(k.get("KLASM", "")).strip()
            vade_adi = str(k.get("VADE_ADI", "")).strip()

            is_kk = ("Kredi Kartı" in vade_adi or "Peşin" in vade_adi or "Online" in vade_adi or k_klasm == "004")
            vade = 0 if is_kk else 30
            if not is_kk:
                v_match = re.search(r"\d+", vade_adi)
                if v_match:
                    vade = int(v_match.group(0))

            # İsimlendirme: Tek şart varsa "BEK", çoklu şart varsa "BEK (Kredi Kartı)" / "BEK (90 Gün Vade)"
            if len(klasm) > 1:
                if is_kk:
                    depo_gorunen_ad = "BEK (Kredi Kartı)"
                else:
                    depo_gorunen_ad = f"BEK ({vade} Gün Vade)"
            else:
                depo_gorunen_ad = self.depo_adi

            # Bu KLASM'a ait baremleri filtrele
            matching_baremler = [b for b in baremler if str(b.get("KLASM", "")).strip() == k_klasm]
            if not matching_baremler and len(klasm) == 1:
                matching_baremler = baremler

            k_dsf = float(k.get("DSF") or dsf)
            if k_dsf == 0.0:
                k_dsf = dsf

            k_net = float(k.get("NETFIYAT") or k_dsf)
            en_iyi_net = k_net
            ticari_iskonto = 0.0

            # 1. k içinden iskonto (ZTC1, TEXT_ZTC)
            k_ztc1 = float(str(k.get("ZTC1") or 0).replace(",", "."))
            k_text_ztc = str(k.get("TEXT_ZTC") or "").replace(",", ".").strip()
            if k_ztc1 > 0:
                ticari_iskonto = max(ticari_iskonto, k_ztc1)
            elif k_text_ztc.replace(".", "", 1).isdigit() and float(k_text_ztc) > 0:
                ticari_iskonto = max(ticari_iskonto, float(k_text_ztc))

            # 2. k_net vs k_dsf
            if k_dsf > 0 and k_net > 0 and k_net < (k_dsf - 0.01):
                isk_from_knet = round((1.0 - (k_net / k_dsf)) * 100.0, 2)
                ticari_iskonto = max(ticari_iskonto, isk_from_knet)

            # 3. Baremleri tara
            mf_set = set()
            for b in matching_baremler:
                b_adi = str(b.get("BAREM_ADI", "")).strip()
                if "+" in b_adi:
                    mf_set.add(b_adi.replace(" ", ""))

                b_isk = float(str(b.get("ZTC8_ISK") or 0).replace(",", "."))
                if b_isk > 0:
                    ticari_iskonto = max(ticari_iskonto, b_isk)

                b_nf = float(b.get("NETFIYAT") or 0.0)
                if k_dsf > 0 and b_nf > 0 and b_nf < (k_dsf - 0.01):
                    isk_from_bnf = round((1.0 - (b_nf / k_dsf)) * 100.0, 2)
                    ticari_iskonto = max(ticari_iskonto, isk_from_bnf)

                bf = float(b.get("BIRIMFIYAT") or 0.0)
                fiyat_aday = bf if bf > 0 else b_nf
                if fiyat_aday > 0:
                    if en_iyi_net == 0 or fiyat_aday < en_iyi_net:
                        en_iyi_net = fiyat_aday

            mf_text = " / ".join(sorted(list(mf_set))) if mf_set else "YOK"

            # 4. MF ve ticari iskonto korelasyonu (MF varken de iskonto kontrolü)
            pairs = CostCalculator.parse_mf_pairs(mf_text)
            best_mf_carpan = min((a / (a + h)) for a, h in pairs) if pairs else 1.0
            expected_net_mf = k_dsf * best_mf_carpan

            if k_dsf > 0 and en_iyi_net > 0 and expected_net_mf > 0:
                if en_iyi_net < (expected_net_mf - 0.05):
                    derived_isk = round((1.0 - (en_iyi_net / expected_net_mf)) * 100.0, 2)
                    ticari_iskonto = max(ticari_iskonto, derived_isk)

            maliyet = CostCalculator.calculate(
                dsf=k_dsf if k_dsf > 0 else en_iyi_net,
                psf=psf,
                kdv_orani=kdv_orani,
                mf_str=mf_text,
                ticari_iskonto=ticari_iskonto,
                vade_gun=vade
            )

            final_net = min(en_iyi_net, maliyet.net_birim_maliyet) if (en_iyi_net > 0 and maliyet.net_birim_maliyet > 0) else maliyet.net_birim_maliyet
            final_net_kdvli = round(final_net * (1.0 + (kdv_orani / 100.0)), 2)

            notlar = [f"{vade} Gün Vade" if vade > 0 else "Peşin / Kredi Kartı"]
            if mf_text != "YOK":
                notlar.append(f"MF: {mf_text}")
            if ticari_iskonto > 0:
                notlar.append(f"İsk: %{ticari_iskonto}")

            sarti = DepoUrunSarti(
                depo=DepoKodu.BEK,
                depo_adi=depo_gorunen_ad,
                barkod=barkod,
                urun_id=matnr,
                urun_adi=ad,
                stok_durumu=stok_durumu,
                stok_adedi=None,
                depocu_satis_fiyati=round(k_dsf, 2),
                perakende_satis_fiyati=round(psf, 2),
                kdv_orani=kdv_orani,
                mf_metni=mf_text,
                kademeler=maliyet.kademeler,
                ticari_iskonto=round(ticari_iskonto, 2),
                vade_gun=vade,
                net_birim_maliyet=round(final_net, 2),
                net_birim_maliyet_kdvli=final_net_kdvli,
                toplam_indirim_yuzdesi=maliyet.toplam_iskonto_orani,
                ozel_kampanya_notu=" • ".join(notlar)
            )
            sonuclar.append(sarti)

        return sonuclar

    async def add_to_cart(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        """BEK taslak siparişine ürün ekler."""
        if not self.is_logged_in:
            await self.login()
        await self._ensure_ready_page()

        barkod = str(kwargs.get("barkod") or urun_id).strip()
        print(f"[BEK] Sepete ekleniyor: Barkod/ID={barkod}, Miktar={miktar}")

        # 1. Ağ yanıtlarını dinle
        captured_order = {}
        async def on_resp(res):
            if "order/oc" in res.url or "order/ab" in res.url:
                try:
                    captured_order[res.url] = await res.json()
                except Exception:
                    pass
        self._page.on("response", on_resp)

        try:
            # 2. Arama kutusuna barkodu yaz ve Enter yap
            search_input = await self._page.wait_for_selector('input[placeholder*="Barkod"], #input-99', timeout=10000)
            await search_input.fill(barkod)

            try:
                async with self._page.expect_response(lambda r: "rfc/mat/ms" in r.url, timeout=9000):
                    await search_input.press("Enter")
            except Exception:
                await search_input.press("Enter")

            await asyncio.sleep(0.8)

            # 3. Vue durumunu kontrol et
            state = await self._page.evaluate("""() => {
                const btn = document.querySelector('.add-to-basket-btn');
                if (!btn) return { found: false };
                const p = btn.__vue__ ? btn.__vue__.$parent : null;
                const store = p ? p.$store : null;
                const activeBasket = store ? store.getters['basket/getActiveBasket'] : null;
                const alreadyInBasket = store ? store.getters['basket/hasAnyBasketContainsAddingProduct'] : false;
                return {
                    found: true,
                    btnDisabled: !!btn.disabled,
                    alreadyInBasket: !!alreadyInBasket,
                    activeBasketId: activeBasket ? activeBasket.id : null,
                    productName: p && p.dataModel ? p.dataModel.name : null
                };
            }""")

            if not state.get("found"):
                try:
                    await self._page.wait_for_selector(".add-to-basket-btn", timeout=4000)
                    state = await self._page.evaluate("""() => {
                        const btn = document.querySelector('.add-to-basket-btn');
                        if (!btn) return { found: false };
                        const p = btn.__vue__ ? btn.__vue__.$parent : null;
                        const store = p ? p.$store : null;
                        const activeBasket = store ? store.getters['basket/getActiveBasket'] : null;
                        const alreadyInBasket = store ? store.getters['basket/hasAnyBasketContainsAddingProduct'] : false;
                        return {
                            found: true,
                            btnDisabled: !!btn.disabled,
                            alreadyInBasket: !!alreadyInBasket,
                            activeBasketId: activeBasket ? activeBasket.id : null,
                            productName: p && p.dataModel ? p.dataModel.name : null
                        };
                    }""")
                except Exception:
                    pass

            if not state.get("found"):
                return {
                    "success": False,
                    "depo": "BEK",
                    "message": "Ürün BEK'te sepete ekleme için bulunamadı veya stok mevcut değil."
                }

            product_name = state.get("productName") or barkod

            # Ürün zaten taslak sepette mevcut ise
            if state.get("alreadyInBasket"):
                doc_no = state.get("activeBasketId") or ""
                msg = f"{product_name} zaten BEK taslak sepetinizde kayıtlı."
                if doc_no:
                    msg += f" (Belge No: {doc_no})"
                return {
                    "success": True,
                    "depo": "BEK",
                    "message": msg,
                    "urun_adi": product_name,
                    "belge_no": doc_no,
                    "already_in_cart": True
                }

            # 4. Miktar 1'den büyükse Vue modelinde güncelle
            if int(miktar) > 1:
                await self._page.evaluate("""(m) => {
                    const btn = document.querySelector('.add-to-basket-btn');
                    if (btn && btn.__vue__ && btn.__vue__.$parent && btn.__vue__.$parent.dataModel) {
                        btn.__vue__.$parent.dataModel.quantity = m;
                    }
                }""", int(miktar))
                await asyncio.sleep(0.3)

            # 5. Playwright ile butona tıkla
            try:
                await self._page.click(".add-to-basket-btn", timeout=5000)
            except Exception:
                await self._page.evaluate("""() => {
                    const b = document.querySelector('.add-to-basket-btn');
                    if (b) b.click();
                }""")

            # 6. Sipariş yanıtını bekle
            for _ in range(15):
                await asyncio.sleep(0.4)
                if any("order/oc" in u or "order/ab" in u for u in captured_order):
                    break

            oc_data = None
            for u, d in captured_order.items():
                if "order/oc" in u:
                    oc_data = d
                    break
                elif "order/ab" in u and not oc_data:
                    oc_data = d

            if oc_data:
                vbeln = oc_data.get("VBELN", "")
                toplam_tutar = oc_data.get("TOPLAM_TUTAR")
                return {
                    "success": True,
                    "depo": "BEK",
                    "message": f"{product_name} ({miktar} adet) BEK taslak siparişine eklendi (Belge No: {vbeln}).",
                    "belge_no": vbeln,
                    "miktar": int(miktar),
                    "urun_adi": product_name,
                    "cart_total": toplam_tutar
                }
            else:
                return {
                    "success": True,
                    "depo": "BEK",
                    "message": f"{product_name} ({miktar} adet) BEK taslak siparişine eklendi.",
                    "miktar": int(miktar),
                    "urun_adi": product_name
                }
        finally:
            try:
                self._page.remove_listener("response", on_resp)
            except Exception:
                pass

    async def close(self):
        if self._page:
            await self._page.close()
        if self._context:
            await self._context.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
