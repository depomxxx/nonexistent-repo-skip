import os
import asyncio
import json
import re
from typing import List, Optional, Dict, Any
from pathlib import Path
import httpx
from bs4 import BeautifulSoup

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu, MFKademeDetay
from backend.core.cost_calculator import CostCalculator
from backend.core.session_store import SessionStore

def clean_float(val: Any) -> float:
    if val is None or val == "":
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    s = str(val).replace("₺", "").replace("TL", "").strip()
    if not s:
        return 0.0
    if "." in s and "," in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except Exception:
        return 0.0

class DNAEczaAdapter(BaseDepoAdapter):
    LOGIN_URL = "https://eticaret.dnaecza.com/Auth/Login"
    BASE_URL = "https://eticaret.dnaecza.com"
    SEARCH_URL = "https://eticaret.dnaecza.com/Products/UrlDataSource/"
    DETAIL_URL = "https://eticaret.dnaecza.com/Products/GetDrugDetail"
    ADD_CART_URL = "https://eticaret.dnaecza.com/Cart/AddProductSepet"
    GET_BASKET_URL = "https://eticaret.dnaecza.com/Cart/GetBasket"
    REMOVE_CART_URL = "https://eticaret.dnaecza.com/Cart/RemoveProductSepet"

    def __init__(self, username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.DNA, "DNA Ecza Deposu")
        self.username = username or os.environ.get("DNA_USERNAME", "")
        self.password = password or os.environ.get("DNA_PASSWORD", "")
        self.headless = headless
        
        self._session_cookies: Dict[str, str] = {}
        self._client: Optional[httpx.AsyncClient] = None
        self._load_cached_session()

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept": "application/json, text/javascript, */*; q=0.01",
                "X-Requested-With": "XMLHttpRequest",
                "Accept-Language": "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7",
            }
            self._client = httpx.AsyncClient(
                cookies=self._session_cookies,
                headers=headers,
                timeout=20.0,
                follow_redirects=True
            )
        return self._client

    def _load_cached_session(self):
        try:
            sfile = SessionStore.get_session_file("dna")
            if sfile.exists():
                with open(sfile, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        self._session_cookies = data.get("cookies", {})
        except Exception:
            self._session_cookies = {}

    def _save_session(self):
        try:
            sfile = SessionStore.get_session_file("dna")
            if self._client:
                cookies_dict = dict(self._client.cookies)
                with open(sfile, "w", encoding="utf-8") as f:
                    json.dump({"cookies": cookies_dict}, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[DNA] Çerez kaydetme hatası: {e}")

    async def is_session_valid(self) -> bool:
        if not self._session_cookies:
            return False
        client = self._get_client()
        try:
            # Sepet sorgusuyla oturum canlı mı kontrol et
            res = await client.post(self.GET_BASKET_URL, timeout=8.0)
            if res.status_code == 200:
                data = res.json()
                if isinstance(data, dict) and data.get("success") is True:
                    return True
        except Exception:
            pass
        return False

    async def login(self) -> bool:
        """DNA Ecza Deposu B2B portalına giriş yapar."""
        if not self.username or not self.password:
            raise ValueError("DNA Ecza Deposu için Kullanıcı Adı ve Şifre zorunludur.")

        client = self._get_client()

        # 1. Önce kayıtlı çerezle oturum kontrolü
        if await self.is_session_valid():
            print("[DNA] Mevcut oturum aktif, doğrudan bağlanıldı.")
            self.is_logged_in = True
            return True

        print("[DNA] Giriş yapılıyor...")
        try:
            # Login sayfasından form bilgilerini al
            login_page = await client.get(self.LOGIN_URL, timeout=15.0)
            soup = BeautifulSoup(login_page.text, "html.parser")
            form = soup.find("form")
            inputs = {}
            if form:
                inputs = {inp.get("name"): inp.get("value", "") for inp in form.find_all("input") if inp.get("name")}

            login_data = {
                "username": self.username,
                "password": self.password,
                "remember_me": "true",
                "gRecaptchaResponse": ""
            }
            for k, v in inputs.items():
                if k not in login_data:
                    login_data[k] = v

            post_resp = await client.post(self.LOGIN_URL, data=login_data, timeout=15.0)
            
            # Başarılı giriş kontrolü
            cookies_dict = dict(client.cookies)
            if ".AspNetCore.Cookies" in cookies_dict or "Login" not in str(post_resp.url):
                print("[DNA] Giriş başarılı, oturum çerezleri kaydedildi.")
                self._save_session()
                self.is_logged_in = True
                return True
            else:
                raise RuntimeError("Giriş başarısız! Lütfen kullanıcı adı ve şifrenizi kontrol edin.")
        except Exception as e:
            self.is_logged_in = False
            raise RuntimeError(f"DNA Ecza giriş hatası: {e}")

    async def search_product(self, query: str) -> List[DepoUrunSarti]:
        """DNA Ecza Deposu'nda barkod veya ilaç adına göre arama yapar."""
        if not self.is_logged_in:
            await self.login()

        clean_q = query.strip()
        client = self._get_client()

        search_payload = {
            "requiresCounts": True,
            "skip": 0,
            "take": 15,
            "search": [
                {
                    "fields": ["urunadi", "barkodu"],
                    "key": clean_q,
                    "operator": "contains",
                    "ignoreCase": True
                }
            ]
        }

        try:
            res = await client.post(self.SEARCH_URL, json=search_payload, timeout=12.0)
            if res.status_code != 200:
                # Oturum düşmüş olabilir, tekrar giriş dene
                await self.login()
                res = await client.post(self.SEARCH_URL, json=search_payload, timeout=12.0)
        except Exception as e:
            print(f"[DNA] Arama isteği hatası: {e}")
            return []

        if res.status_code != 200:
            return []

        try:
            data = res.json()
            raw_items = data.get("result", []) if isinstance(data, dict) else []
        except Exception:
            return []

        sonuclar: List[DepoUrunSarti] = []
        is_query_barcode = bool(clean_q.isdigit() and len(clean_q) >= 8)

        for item in raw_items:
            stok_kodu = str(item.get("stoK_KODU") or "").strip()
            urun_adi = str(item.get("stoK_ADI") or "").strip()
            item_barkod = str(item.get("barkod") or item.get("barkoD1") or "").strip()
            if not item_barkod and is_query_barcode:
                item_barkod = clean_q

            # Eğer barkod ile arandıysa ve eşleşmiyorsa atla
            if is_query_barcode and item_barkod and item_barkod != clean_q:
                continue

            stok_adedi = int(item.get("stok") or item.get("adet") or 0)
            stok_durumu = StokDurumu.VAR if stok_adedi > 0 else StokDurumu.YOK

            dsf = clean_float(item.get("bf") or item.get("depO_FIYAT") or item.get("gosterimfiyat") or 0.0)
            psf = clean_float(item.get("psf") or item.get("etkfiat") or 0.0)
            kdv_orani = clean_float(item.get("kdV_ORANI", 10.0))
            skt = str(item.get("skt") or "").strip()
            base_birim_fiyat = clean_float(item.get("gosterimfiyat") or dsf)

            # Kampanya ve MF detaylarını çek
            kademeler: List[MFKademeDetay] = []
            mf_list: List[str] = []
            base_camp_net = base_birim_fiyat
            best_tier_net = base_birim_fiyat
            vade_gun = 30
            kamu_iskontosu = clean_float(item.get("isK2") or 0.0)
            ticari_iskonto = clean_float(item.get("isK3") or item.get("isK1") or 0.0)

            try:
                det_res = await client.get(f"{self.DETAIL_URL}?stokKodu={stok_kodu}", timeout=6.0)
                if det_res.status_code == 200:
                    det_data = det_res.json()
                    campaigns = det_data.get("kampanyalar", [])
                    
                    # 1. Önce taban 1+0 kampanyasını (MF-000 veya BF-000) bul
                    base_c = next((c for c in campaigns if c.get("kampanya") == "MF-000"), None)
                    if not base_c:
                        base_c = next((c for c in campaigns if c.get("kampanya") == "BF-000"), None)
                    if base_c:
                        base_camp_net = clean_float(base_c.get("gosterimfiyat") or base_c.get("netfiyat") or dsf)
                        c_dsf = clean_float(base_c.get("depO_FIYAT"))
                        if c_dsf > 0:
                            dsf = c_dsf
                        if base_c.get("vade"):
                            vade_gun = int(base_c.get("vade"))

                    # 2. MF Kademelerini oluştur
                    for camp in campaigns:
                        m_k = int(camp.get("mK1") or 0)
                        m_f = int(camp.get("mF1") or 0)
                        c_fiyat = clean_float(camp.get("gosterimfiyat") or camp.get("netfiyat") or 0.0)
                        c_vade = int(camp.get("vade") or 0)
                        c_dsf = clean_float(camp.get("depO_FIYAT") or dsf)
                        
                        if c_dsf > 0 and dsf == 0:
                            dsf = c_dsf
                        if c_vade > 0 and vade_gun == 30:
                            vade_gun = c_vade
                        if camp.get("isK2") and kamu_iskontosu == 0:
                            kamu_iskontosu = clean_float(camp.get("isK2"))

                        # MF Kademesi varsa
                        if m_f > 0 and m_k > 0:
                            mf_str = f"{m_k}+{m_f}"
                            if mf_str not in mf_list:
                                mf_list.append(mf_str)
                            
                            # Net birim maliyet (KDV hariç)
                            c_net = c_fiyat if c_fiyat > 0 else (dsf * m_k / (m_k + m_f))
                            c_net_kdvli = round(c_net * (1 + kdv_orani / 100), 2)
                            isk_yuzde = round((1 - (c_net / dsf)) * 100, 2) if dsf > 0 else 0.0
                            
                            kademeler.append(MFKademeDetay(
                                alinan=m_k,
                                hediye=m_f,
                                mf_text=mf_str,
                                net_birim_maliyet=round(c_net, 2),
                                net_birim_maliyet_kdvli=c_net_kdvli,
                                toplam_iskonto_yuzdesi=isk_yuzde
                            ))
                            if c_net > 0 and (best_tier_net == 0 or c_net < best_tier_net):
                                best_tier_net = c_net
            except Exception as e:
                pass

            if dsf == 0 and base_camp_net > 0:
                dsf = base_camp_net

            # Net birim maliyet: MF baremi varsa en avantajlı baremi (tüm depolarla standart), yoksa 1 adet taban fiyatı
            if best_tier_net > 0:
                final_net = best_tier_net
            else:
                final_net = base_camp_net if base_camp_net > 0 else dsf

            final_net_kdvli = round(final_net * (1 + kdv_orani / 100), 2)
            toplam_indirim = round((1 - (final_net / dsf)) * 100, 2) if dsf > 0 else 0.0

            sarti = DepoUrunSarti(
                depo=DepoKodu.DNA,
                depo_adi="DNA Ecza Deposu",
                barkod=item_barkod,
                urun_id=stok_kodu,
                urun_adi=urun_adi,
                stok_durumu=stok_durumu,
                stok_adedi=stok_adedi,
                depocu_satis_fiyati=round(dsf, 2),
                perakende_satis_fiyati=round(psf, 2),
                kdv_orani=kdv_orani,
                mf_metni=" / ".join(mf_list) if mf_list else "YOK",
                kademeler=kademeler,
                ticari_iskonto=ticari_iskonto,
                kamu_iskontosu=kamu_iskontosu,
                vade_gun=vade_gun,
                net_birim_maliyet=round(final_net, 2),
                net_birim_maliyet_kdvli=final_net_kdvli,
                toplam_indirim_yuzdesi=toplam_indirim,
                miad=skt or None,
                soguk_zincir=bool("SOĞUK" in urun_adi.upper() or "+2" in urun_adi)
            )
            sonuclar.append(sarti)

        return sonuclar

    async def add_to_cart(self, urun_id: str, miktar: int = 1, **kwargs) -> Dict[str, Any]:
        """
        DNA Ecza sepetine ürün ekler.
        Miktara göre otomatik MF kampanyasını seçer veya belirtilen kampanyayı uygular.
        Sepette ürün zaten varsa akıllıca miktarı günceller ve çakışma hatasını önler.
        """
        if not self.is_logged_in:
            await self.login()

        client = self._get_client()
        clean_id = str(urun_id).strip()
        barkod = str(kwargs.get("barkod") or "").strip()
        stok_kodu = clean_id

        # 1. Eğer clean_id barkod ise (örn: 8699536090160), stok kodunu bul
        if clean_id.isdigit() and len(clean_id) >= 8:
            search_res = await self.search_product(clean_id)
            if search_res:
                stok_kodu = search_res[0].urun_id or clean_id
                barkod = search_res[0].barkod
            else:
                return {
                    "success": False,
                    "message": f"Barkod ({clean_id}) DNA Ecza sisteminde bulunamadı."
                }

        # 2. Ürünün kampanyalarını çekerek uygun MF kademesini belirle
        kampanya_kodu = kwargs.get("kampanya_kodu")
        mal_fazlasi = int(kwargs.get("mf", 0))

        if not kampanya_kodu:
            try:
                det_res = await client.get(f"{self.DETAIL_URL}?stokKodu={stok_kodu}", timeout=6.0)
                if det_res.status_code == 200:
                    det_data = det_res.json()
                    campaigns = det_data.get("kampanyalar", [])
                    
                    # Kampanyaları alım adedine (mK1) göre büyükten küçüğe sırala
                    mf_campaigns = [c for c in campaigns if int(c.get("mF1") or 0) > 0 and int(c.get("mK1") or 0) > 0]
                    mf_campaigns.sort(key=lambda x: int(x.get("mK1")), reverse=True)
                    
                    # İstenen miktar bir MF baremini karşılıyor mu?
                    matched_camp = None
                    for c in mf_campaigns:
                        req_mk = int(c.get("mK1"))
                        if miktar >= req_mk:
                            matched_camp = c
                            break
                    
                    if matched_camp:
                        kampanya_kodu = matched_camp.get("kampanya")
                        req_mk = int(matched_camp.get("mK1"))
                        req_mf = int(matched_camp.get("mF1"))
                        multiplier = miktar // req_mk
                        mal_fazlasi = multiplier * req_mf
                    else:
                        # MF barajına yetmiyorsa MF-000 veya BF-000
                        base_c = next((c for c in campaigns if c.get("kampanya") == "MF-000"), None)
                        if not base_c:
                            base_c = next((c for c in campaigns if c.get("kampanya") == "BF-000"), None)
                        kampanya_kodu = base_c.get("kampanya") if base_c else (campaigns[0].get("kampanya") if campaigns else "MF-000")
                        mal_fazlasi = 0
            except Exception as e:
                print(f"[DNA] Kampanya seçimi hatası: {e}")
                kampanya_kodu = "MF-000"
                mal_fazlasi = 0

        if not kampanya_kodu:
            kampanya_kodu = "MF-000"

        print(f"[DNA] Sepete Ekleniyor -> Stok Kodu: {stok_kodu}, Kampanya: {kampanya_kodu}, Miktar: {miktar}, MF: {mal_fazlasi}")

        add_payload = {
            "stokKodu": stok_kodu,
            "kampanyaKodu": kampanya_kodu,
            "amount": miktar,
            "mf": mal_fazlasi
        }

        try:
            res = await client.post(self.ADD_CART_URL, data=add_payload, timeout=12.0)
            data = res.json() if res.status_code == 200 else {}
            
            # Eğer ürün başka kampanya ile sepette varsa veya sepette zaten bulunuyorsa
            if data.get("success") is not True:
                err_msg = data.get("message") or ""
                if "başka bir kampanya" in err_msg.lower() or "sepete eklenmiş" in err_msg.lower():
                    # Sepetteki mevcut ürünü bul, kaldır ve yeni adetle tekrar ekle
                    basket = await self.get_basket()
                    existing = next((b for b in basket if str(b.get("stokkodu", "")).strip() == str(stok_kodu).strip()), None)
                    if existing:
                        await self.remove_from_cart(existing.get("sepetid"))
                        # Yeni miktarı sepete ekle
                        retry_res = await client.post(self.ADD_CART_URL, data=add_payload, timeout=12.0)
                        data = retry_res.json() if retry_res.status_code == 200 else {}

            if data.get("success") is True:
                msg_detail = f"{miktar} Adet"
                if mal_fazlasi > 0:
                    msg_detail += f" + {mal_fazlasi} MF (Kampanya: {kampanya_kodu})"
                return {
                    "success": True,
                    "message": f"DNA Ecza sepetine başarıyla eklendi: {msg_detail}",
                    "depo": "DNA",
                    "data": {
                        "stok_kodu": stok_kodu,
                        "barkod": barkod,
                        "kampanya_kodu": kampanya_kodu,
                        "miktar": miktar,
                        "mf": mal_fazlasi
                    }
                }
            else:
                err_msg = data.get("message") or "Sepete ekleme başarısız oldu."
                return {
                    "success": False,
                    "message": f"DNA Ecza Hatası: {err_msg}"
                }
        except Exception as e:
            return {
                "success": False,
                "message": f"DNA Ecza sepete ekleme bağlantı hatası: {e}"
            }

    async def get_basket(self) -> List[Dict[str, Any]]:
        """DNA Ecza sepetindeki ürünleri listeler."""
        if not self.is_logged_in:
            await self.login()
        client = self._get_client()
        try:
            res = await client.post(self.GET_BASKET_URL, timeout=8.0)
            if res.status_code == 200:
                data = res.json()
                if data.get("success"):
                    return data.get("data", [])
        except Exception as e:
            print(f"[DNA] Sepet listeleme hatası: {e}")
        return []

    async def remove_from_cart(self, sepet_id: int) -> bool:
        """DNA Ecza sepetinden belirtilen öğeyi siler."""
        if not self.is_logged_in:
            await self.login()
        client = self._get_client()
        try:
            res = await client.post(self.REMOVE_CART_URL, data={"sepetId": sepet_id}, timeout=8.0)
            if res.status_code == 200:
                data = res.json()
                return bool(data.get("success"))
        except Exception:
            pass
        return False

    async def close(self):
        """HTTP istemcisini kapatır."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None
