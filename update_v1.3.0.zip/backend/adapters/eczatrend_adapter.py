import asyncio
import json
import logging
import re
import time
from typing import List, Optional, Dict, Any
import httpx

from backend.adapters.base_adapter import BaseDepoAdapter
from backend.models import DepoKodu, DepoUrunSarti, StokDurumu
from backend.core.session_store import SessionStore
from backend.catalog import catalog

logger = logging.getLogger("eczatrend_adapter")


def _norm_tr_name(s: str) -> str:
    if not s:
        return ""
    s = s.upper().translate(str.maketrans("ÇĞİÖŞÜIîÂÊÛ", "CGIOSUIIAEO"))
    return re.sub(r"[^A-Z0-9]", "", s)


class EczatrendAdapter(BaseDepoAdapter):
    """
    Eczatrend (eczatrend.com) Eczaneler Arası Ortak Alım Grubu & Barem Takas Adaptörü.
    'Grubumun Teklifleri' (menualloffer) sayfasındaki kampanyaları, baremleri,
    hedeflenen adetleri, kalan adetleri ve KDV'li/KDV'siz net birim fiyatları çeker.
    """
    LOGIN_URL = "https://eczatrend.com/gtsp/ajax/login"
    MAIN_URL = "https://eczatrend.com/eczanet/panelNew/main"
    PANEL_URL = "https://eczatrend.com/eczanet/panelNew/main"

    _OFFERS_CACHE: List[Dict[str, Any]] = []
    _RAW_OFFERS_CACHE: List[Dict[str, Any]] = []
    _OFFERS_CACHE_TIME: float = 0.0
    _OFFERS_CACHE_TTL: float = 90.0
    _FETCH_LOCK: Optional[asyncio.Lock] = None

    def __init__(self, username: str = "", password: str = "", headless: bool = True):
        super().__init__(DepoKodu.ECZATREND, "Eczatrend Alım Grubu")
        self.username = username.strip()
        self.password = password.strip()
        self.headless = headless
        self.session_data: Optional[Dict[str, Any]] = None
        self._client: Optional[httpx.AsyncClient] = None

    def _get_headers(self) -> Dict[str, str]:
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Origin": "https://eczatrend.com",
            "Referer": "https://eczatrend.com/eczanet/panelNew/main",
            "Content-Type": "application/x-www-form-urlencoded",
            "X-Requested-With": "XMLHttpRequest",
            "Accept": "application/json, text/javascript, */*; q=0.01"
        }

    async def _get_client(self, reset: bool = False) -> httpx.AsyncClient:
        if reset and self._client is not None:
            try:
                await self._client.aclose()
            except Exception:
                pass
            self._client = None
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                headers=self._get_headers(),
                follow_redirects=True,
                timeout=25.0,
                verify=False
            )
            # Kayıtlı oturumu yükle
            cached = SessionStore.load_state("eczatrend")
            if cached and isinstance(cached, dict) and "cookies" in cached:
                for k, v in cached["cookies"].items():
                    self._client.cookies.set(k, v, domain="eczatrend.com")
                self.session_data = cached
        return self._client

    async def is_session_valid(self) -> bool:
        """Kayıtlı oturum çerezinin geçerli olup olmadığını kontrol eder."""
        client = await self._get_client()
        if "eria_session" not in client.cookies:
            return False

        try:
            payload = {
                "action": "purchaseGrid",
                "searchMiadSwitch": "true",
                "searchTargetSwitch": "false",
                "searchPharmacyOfferSwitch": "true",
                "page": "0",
                "priority": "2",
                "productName": "",
                "pharmacy": "",
                "selectedMenu": "menualloffer",
                "directSalesCategory": "",
                "taxFilter": "0"
            }
            resp = await client.post(self.MAIN_URL, data=payload)
            if resp.status_code == 200 and resp.text and resp.text.strip() and not resp.text.startswith("<"):
                data = resp.json()
                if "data" in data or "firstmes" in data:
                    self.is_logged_in = True
                    return True
        except Exception:
            pass
        return False

    async def login(self, force_fresh: bool = False) -> bool:
        """Eczatrend B2B ortak alım portalına giriş yapar."""
        if not self.username or not self.password:
            raise ValueError("Eczatrend için Kullanıcı Adı ve Şifre zorunludur.")

        client = await self._get_client()

        # 1. Mevcut çerez hala geçerli mi?
        if not force_fresh and await self.is_session_valid():
            logger.info("[Eczatrend] Mevcut oturum aktif, doğrudan devam ediliyor.")
            return True

        # Eski/bozuk çerezleri temizle
        client.cookies.clear()
        SessionStore.clear("eczatrend")
        self.is_logged_in = False

        logger.info("[Eczatrend] Oturum açılıyor (%s)...", self.username)
        login_payload = {
            "username": self.username,
            "password": self.password,
            "remember": "true"
        }

        try:
            login_headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                "Origin": "https://eczatrend.com",
                "Referer": "https://eczatrend.com/eczanet/site/sitelogin",
                "X-Requested-With": "XMLHttpRequest"
            }
            resp = await client.post(self.LOGIN_URL, data=login_payload, headers=login_headers)
            if resp.status_code != 200:
                raise RuntimeError(f"Giriş isteği başarısız: HTTP {resp.status_code}")

            res_json = resp.json()
            if not res_json.get("success"):
                err_msg = res_json.get("message") or "Kullanıcı adı veya şifre hatalı."
                raise RuntimeError(f"Eczatrend Giriş Başarısız: {err_msg}")

            # Oturumu kaydet
            cookie_dict = dict(client.cookies)
            state_data = {
                "cookies": cookie_dict,
                "pharmacyName": res_json.get("pharmacyName", ""),
                "userName": res_json.get("userName", ""),
                "userRealName": res_json.get("userRealName", "")
            }
            SessionStore.save_state("eczatrend", state_data)
            self.session_data = state_data
            self.is_logged_in = True
            logger.info("[Eczatrend] Giriş başarılı! Eczane: %s", res_json.get("pharmacyName"))
            return True

        except Exception as e:
            logger.error("[Eczatrend] Giriş hatası: %s", e)
            self.is_logged_in = False
            raise

    async def _query_purchase_grid_json(self, product_name: str = "", offset: int = 0) -> Dict[str, Any]:
        """Eczatrend purchaseGrid uç noktasından ham JSON yanıtını (data + secondmes toplam sayı) döndürür.
        Not: Eczatrend'de 'page' parametresi sayfa numarası değil SQL OFFSET değeridir (0, 24, 48, 72...).
        searchTargetSwitch='false' gönderildiğinde hedefi dolmuş (kapalı) teklifler elenir, yalnızca açık teklifler gelir.
        """
        client = await self._get_client()
        if not self.is_logged_in:
            await self.login()

        payload = {
            "action": "purchaseGrid",
            "searchMiadSwitch": "true",
            "searchTargetSwitch": "false",
            "searchPharmacyOfferSwitch": "true",
            "page": str(offset),
            "priority": "2",
            "productName": product_name,
            "pharmacy": "",
            "selectedMenu": "menualloffer",
            "directSalesCategory": "",
            "taxFilter": "0"
        }

        for attempt in range(2):
            try:
                resp = await client.post(self.MAIN_URL, data=payload)
            except RuntimeError:
                client = await self._get_client(reset=True)
                resp = await client.post(self.MAIN_URL, data=payload)

            if resp.status_code != 200 or resp.text.startswith("<") or "sitelogin" in resp.text:
                logger.warning("[Eczatrend] Oturum süresi dolmuş, yeniden giriş yapılıyor...")
                await self.login(force_fresh=True)
                resp = await client.post(self.MAIN_URL, data=payload)

            if resp.status_code == 200 and resp.text and resp.text.strip() and not resp.text.startswith("<"):
                try:
                    return resp.json()
                except Exception:
                    pass
            await asyncio.sleep(0.12)

        return {}

    async def _query_purchase_grid(self, product_name: str = "", page: int = 0) -> List[Dict[str, Any]]:
        """Eczatrend purchaseGrid uç noktasından ham teklif listesini döndürür."""
        j = await self._query_purchase_grid_json(product_name=product_name, offset=page)
        return j.get("data") or []

    async def get_active_offers(self, force_refresh: bool = False, search_query: str = "") -> List[Dict[str, Any]]:
        """
        Eczatrend 'Grubumun Teklifleri' sayfasındaki TÜM aktif ortak alım tekliflerini
        (SQL offset: 0, 24, 48, ... üzerinden paralel çekerek) normalize edilmiş sözlük listesi olarak döndürür.
        """
        now = time.time()
        clean_sq = (search_query or "").strip()

        if not clean_sq and not force_refresh and EczatrendAdapter._OFFERS_CACHE and (now - EczatrendAdapter._OFFERS_CACHE_TIME < EczatrendAdapter._OFFERS_CACHE_TTL):
            return EczatrendAdapter._OFFERS_CACHE

        if EczatrendAdapter._FETCH_LOCK is None:
            EczatrendAdapter._FETCH_LOCK = asyncio.Lock()

        async with EczatrendAdapter._FETCH_LOCK:
            now = time.time()
            if not clean_sq and not force_refresh and EczatrendAdapter._OFFERS_CACHE and (now - EczatrendAdapter._OFFERS_CACHE_TIME < EczatrendAdapter._OFFERS_CACHE_TTL):
                return EczatrendAdapter._OFFERS_CACHE

            j0 = await self._query_purchase_grid_json(product_name=clean_sq, offset=0)
            raw_all: List[Dict[str, Any]] = list(j0.get("data") or [])
            try:
                total_reported = int(str(j0.get("secondmes") or "0").strip())
            except Exception:
                total_reported = len(raw_all)

            max_offset = min(total_reported, 240 if clean_sq else 1500)
            if len(raw_all) >= 24 and max_offset > 24:
                offsets = list(range(24, max_offset, 24))
                sem = asyncio.Semaphore(6)

                async def _fetch_offset(off: int) -> List[Dict[str, Any]]:
                    async with sem:
                        try:
                            j_page = await self._query_purchase_grid_json(product_name=clean_sq, offset=off)
                            return j_page.get("data") or []
                        except Exception as e:
                            logger.warning("[Eczatrend] Offset %d çekilirken hata: %s", off, e)
                            return []

                pages = await asyncio.gather(*(_fetch_offset(o) for o in offsets))
                for p_items in pages:
                    if p_items:
                        raw_all.extend(p_items)

            seen_pks = set()
            normalized_offers: List[Dict[str, Any]] = []
            for it in raw_all:
                offer_pk = str(it.get("offerPK") or "").strip()
                if offer_pk and offer_pk in seen_pks:
                    continue
                if offer_pk:
                    seen_pks.add(offer_pk)

                try:
                    left_target = int(float(str(it.get("leftTarget") or "0").strip()))
                except Exception:
                    left_target = 0
                if left_target <= 0:
                    continue

                try:
                    target_amount = int(float(str(it.get("offertarget") or "0").strip()))
                except Exception:
                    target_amount = 0

                try:
                    total_purchase = int(float(str(it.get("totalPurchase") or "0").strip()))
                except Exception:
                    total_purchase = 0

                try:
                    net_price_kdvli = float(str(it.get("netprice") or "0").replace(",", ".").strip())
                except Exception:
                    net_price_kdvli = 0.0

                try:
                    net_price_kdvsiz = float(str(it.get("vatExcludedNetPrice") or "0").replace(",", ".").strip())
                except Exception:
                    net_price_kdvsiz = 0.0

                try:
                    market_price = float(str(it.get("marketPrice") or "0").replace(",", ".").strip())
                except Exception:
                    market_price = 0.0

                try:
                    product_price = float(str(it.get("productPrice") or "0").replace(",", ".").strip())
                except Exception:
                    product_price = 0.0

                try:
                    product_vat = float(str(it.get("productVat") or "10").replace(",", ".").strip())
                except Exception:
                    product_vat = 10.0

                p_bc = str(it.get("productBarcode") or "").strip()
                p_name = str(it.get("productName") or "").strip()
                offer_mf = str(it.get("offerMF") or "").strip()
                pharmacy_name = str(it.get("pharmacy") or "Grup Eczanesi").strip()
                group_name = str(it.get("groupName") or "Ortak Alım").strip()
                expire_dt = str(it.get("expireDT") or "").strip()
                offer_load = str(it.get("offerload") or "0").strip()

                normalized_offers.append({
                    "offer_id": offer_pk,
                    "urun_adi": p_name,
                    "barcode": p_bc,
                    "satici": pharmacy_name,
                    "groupName": group_name,
                    "mf": offer_mf,
                    "hedef": target_amount,
                    "alinan": total_purchase,
                    "kalan": left_target,
                    "doluluk": f"%{offer_load}",
                    "depo_fiyati": market_price,
                    "psf": product_price,
                    "kdv": product_vat,
                    "fiyat_kdvsiz": net_price_kdvsiz,
                    "fiyat_kdvli": net_price_kdvli,
                    "kalan_sure": expire_dt,
                    "katil_url": "https://eczatrend.com/eczanet/panelNew/main"
                })

            if not clean_sq:
                EczatrendAdapter._OFFERS_CACHE = normalized_offers
                EczatrendAdapter._RAW_OFFERS_CACHE = raw_all
                EczatrendAdapter._OFFERS_CACHE_TIME = time.time()

            return normalized_offers

    async def search_product(self, query: str, include_equivalents: bool = False, is_background: bool = False) -> List[DepoUrunSarti]:
        """
        'Grubumun Teklifleri' (menualloffer) listesinde ürün veya barkod sorgular.
        Teklifin baremini, hedefini, kalan miktarını ve birim fiyatını çeker.
        """
        clean_q = query.strip()
        if not clean_q:
            return []

        try:
            is_barcode_query = clean_q.isdigit() and len(clean_q) >= 8
            catalog_name = None
            if is_barcode_query:
                try:
                    prod = catalog.get_by_barcode(clean_q)
                    if prod and prod.get("name"):
                        catalog_name = prod["name"]
                except Exception:
                    pass

            # Önce önbellekteki (675+ aktif grup teklifi) tam listeden eşleşme kontrolü yap
            if EczatrendAdapter._RAW_OFFERS_CACHE and (time.time() - EczatrendAdapter._OFFERS_CACHE_TIME < EczatrendAdapter._OFFERS_CACHE_TTL):
                cached_res = self._parse_offer_items(EczatrendAdapter._RAW_OFFERS_CACHE, clean_q, catalog_name=catalog_name)
                if cached_res:
                    return cached_res

            raw_items = await self._query_purchase_grid(product_name=clean_q, page=0)

            if not raw_items and is_barcode_query and catalog_name and not is_background:
                first_word = catalog_name.split()[0] if catalog_name.split() else ""
                if len(first_word) >= 3:
                    raw_items = await self._query_purchase_grid(product_name=first_word, page=0)

            if not raw_items:
                return []

            return self._parse_offer_items(raw_items, clean_q, catalog_name=catalog_name)

        except Exception as e:
            logger.error("[Eczatrend] Arama sırasında hata: %s", e)
            return []

    def _parse_offer_items(self, items: List[Dict[str, Any]], query: str, catalog_name: Optional[str] = None) -> List[DepoUrunSarti]:
        """Eczatrend API'sinden gelen teklif listesini DepoUrunSarti formatına dönüştürür."""
        is_barcode_query = query.isdigit() and len(query) >= 8
        query_lower = query.lower()
        norm_cat = _norm_tr_name(catalog_name) if catalog_name else ""
        norm_q = _norm_tr_name(query) if not is_barcode_query else ""

        matched_offers = []
        for it in items:
            p_bc = str(it.get("productBarcode") or "").strip()
            p_name = str(it.get("productName") or "").strip()
            norm_p = _norm_tr_name(p_name)

            # Barkod veya isim eşleşmesi
            if is_barcode_query:
                bc_ok = (p_bc == query or query in p_bc)
                name_ok = bool(norm_cat and norm_p and (norm_cat in norm_p or norm_p in norm_cat))
                if not (bc_ok or name_ok):
                    continue
            else:
                if query_lower not in p_name.lower() and query_lower not in p_bc and (not norm_q or norm_q not in norm_p):
                    continue

            matched_offers.append(it)

        if not matched_offers:
            return []

        # Her teklif detayını hazırla
        pazaryeri_teklifleri = []
        for it in matched_offers:
            try:
                left_target = int(float(str(it.get("leftTarget") or "0").strip()))
            except Exception:
                left_target = 0

            try:
                target_amount = int(float(str(it.get("offertarget") or "0").strip()))
            except Exception:
                target_amount = 0

            try:
                total_purchase = int(float(str(it.get("totalPurchase") or "0").strip()))
            except Exception:
                total_purchase = 0

            try:
                net_price_kdvli = float(str(it.get("netprice") or "0").replace(",", ".").strip())
            except Exception:
                net_price_kdvli = 0.0

            try:
                net_price_kdvsiz = float(str(it.get("vatExcludedNetPrice") or "0").replace(",", ".").strip())
            except Exception:
                net_price_kdvsiz = 0.0

            try:
                market_price = float(str(it.get("marketPrice") or "0").replace(",", ".").strip())
            except Exception:
                market_price = 0.0

            try:
                product_price = float(str(it.get("productPrice") or "0").replace(",", ".").strip())
            except Exception:
                product_price = 0.0

            try:
                product_vat = float(str(it.get("productVat") or "10").replace(",", ".").strip())
            except Exception:
                product_vat = 10.0

            offer_mf = str(it.get("offerMF") or "").strip()
            pharmacy_name = str(it.get("pharmacy") or "Grup Eczanesi").strip()
            group_name = str(it.get("groupName") or "Ortak Alım").strip()
            expire_dt = str(it.get("expireDT") or "").strip()
            offer_pk = str(it.get("offerPK") or "").strip()
            offer_load = str(it.get("offerload") or "0").strip()

            pazaryeri_teklifleri.append({
                "offer_id": offer_pk,
                "satici": pharmacy_name,
                "pharmacy": pharmacy_name,
                "groupName": group_name,
                "fiyat": net_price_kdvli,
                "fiyat_kdvsiz": net_price_kdvsiz,
                "depocu_fiyat": market_price,
                "psf": product_price,
                "kdv": product_vat,
                "mf": offer_mf,
                "hedef": target_amount,
                "kalan": left_target,
                "alinan": total_purchase,
                "doluluk": f"%{offer_load}",
                "kalan_sure": expire_dt,
                "tur": str(it.get("offerSpecialTypeFK") or "Grup Teklifi"),
                "durum": "Alıma Açık" if left_target > 0 else "Hedefe Ulaştı (Kapalı)"
            })

        # Sadece açık teklifleri (kalan > 0) öne al; hiç açık teklif yoksa karşılaştırma tablosunu kalabalıklaştırma
        open_offers = [x for x in pazaryeri_teklifleri if x["kalan"] > 0]
        if not open_offers:
            return []

        open_offers.sort(key=lambda x: (x["fiyat"] if x["fiyat"] > 0 else 999999))

        best = open_offers[0]
        first_raw = matched_offers[0]

        primary_barcode = str(first_raw.get("productBarcode") or (query if is_barcode_query else "")).strip()
        primary_name = str(first_raw.get("productName") or f"Ürün ({primary_barcode})").strip()

        stok_durumu = StokDurumu.VAR
        kalan_adet = best["kalan"]
        hedef_adet = best["hedef"]
        mf_text = best["mf"] or "BAREM"

        kampanya_notu = (
            f"🎯 Barem: {mf_text} | Kalan: {kalan_adet} Adet (Hedef: {hedef_adet}, Doluluk: {best['doluluk']}) | "
            f"Eczane: {best['satici']} ({best['groupName']})"
        )

        depocu_fiyat = best["depocu_fiyat"]
        net_maliyet = best["fiyat_kdvsiz"]
        net_kdvli = best["fiyat"]

        # İndirim yüzdesi
        indirim = 0.0
        if depocu_fiyat > 0 and net_maliyet > 0:
            indirim = round((1 - (net_maliyet / depocu_fiyat)) * 100, 2)

        sart = DepoUrunSarti(
            depo=DepoKodu.ECZATREND,
            depo_adi="Eczatrend (Alım Grubu)",
            barkod=primary_barcode,
            urun_id=best["offer_id"],
            urun_adi=primary_name,
            stok_durumu=stok_durumu,
            stok_adedi=kalan_adet,
            depocu_satis_fiyati=depocu_fiyat,
            perakende_satis_fiyati=best["psf"],
            kdv_orani=best["kdv"],
            mf_metni=mf_text,
            ticari_iskonto=0.0,
            vade_gun=30,
            net_birim_maliyet=net_maliyet,
            net_birim_maliyet_kdvli=net_kdvli,
            toplam_indirim_yuzdesi=indirim,
            miad=best["kalan_sure"],
            ozel_kampanya_notu=kampanya_notu,
            pazaryeri_teklifleri=open_offers
        )

        return [sart]

    async def close(self):
        """HTTP bağlantısını kapatır."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None
