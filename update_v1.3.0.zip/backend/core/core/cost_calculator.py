"""
Eczacılık Depo Şartları ve MF (Mal Fazlası) Maliyet Hesaplama Motoru
Eczane Matematiği:
Örn: 95+5 MF şartında 95 kutu parası ödenip 100 kutu teslim alınır.
Birim Kutu Maliyeti = (95 * DSF) / 100 = DSF * 0.95 (KDV Hariç)
KDV Dahil = Birim Maliyet * (1 + KDV / 100)
"""

from dataclasses import dataclass
from typing import Optional, Tuple, List
import re
from backend.models import MFKademeDetay

@dataclass
class MaliyetDetayi:
    dsf: float                  # Depocu Satış Fiyatı (KDV hariç)
    psf: float                  # Perakende Satış Fiyatı
    kdv_orani: float            # KDV % (örn: %10 veya %20)
    mf_metni: str               # "25+1 / 95+5" veya "YOK"
    alinan_adet: int            # En iyi kademe için baz adet (örn: 95)
    mf_adet: int                # En iyi kademe için hediye adet (örn: 5)
    mf_iskonto_orani: float     # MF'nin yüzde iskonto karşılığı (örn: 5/100 = %5.00)
    ticari_iskonto_orani: float # Depo ticari iskontosu %
    toplam_iskonto_orani: float # MF + İskonto birleşik indirim oranı
    net_birim_maliyet: float    # Kutu başına gerçek net maliyet (KDV hariç)
    net_birim_maliyet_kdvli: float # Kutu başına net maliyet (KDV dahil)
    vade_gun: int               # Vade
    kademeler: List[MFKademeDetay] # Tüm kademeler

class CostCalculator:
    @staticmethod
    def parse_mf_pairs(mf_str: Optional[str]) -> List[Tuple[int, int]]:
        """
        '25+1 / 95+5' veya '10+1 / 20+3' gibi tüm kademeleri [(25, 1), (95, 5)] olarak çıkarır.
        """
        if not mf_str or mf_str.strip().upper() in ["YOK", "-", "", "0", "0+0", "PAZARYERI"]:
            return []
        
        pairs = []
        # Tüm A+B veya A + B eşleşmelerini bul
        matches = re.findall(r"(\d+)\s*\+\s*(\d+)", mf_str)
        for alinan, hediye in matches:
            a, h = int(alinan), int(hediye)
            if a > 0 and h > 0:
                pairs.append((a, h))
        return pairs

    @classmethod
    def calculate(
        cls,
        dsf: float,
        psf: float = 0.0,
        kdv_orani: float = 10.0,
        mf_str: str = "YOK",
        ticari_iskonto: float = 0.0,
        vade_gun: int = 30
    ) -> MaliyetDetayi:
        """
        Depo şartlarına göre tüm MF kademelerini ve en avantajlı net maliyeti hesaplar.
        """
        pairs = cls.parse_mf_pairs(mf_str)
        kademeler: List[MFKademeDetay] = []
        
        isk_carpan = (1.0 - (ticari_iskonto / 100.0)) if ticari_iskonto > 0 else 1.0

        en_iyi_net = dsf * isk_carpan
        en_iyi_alinan = 1
        en_iyi_hediye = 0
        en_iyi_mf_isk = 0.0

        if pairs:
            for alinan, hediye in pairs:
                toplam = alinan + hediye
                # MF Mantığı: 'alinan' kutu parası ödenir, 'toplam' kutu alınır
                # Kutu başına düşen maliyet = dsf * (alinan / toplam) * isk_carpan
                mf_carpan = alinan / toplam
                kademe_net = round(dsf * mf_carpan * isk_carpan, 2)
                kademe_kdvli = round(kademe_net * (1.0 + (kdv_orani / 100.0)), 2)
                mf_isk_yuzde = round((hediye / toplam) * 100.0, 2)

                kademeler.append(MFKademeDetay(
                    alinan=alinan,
                    hediye=hediye,
                    mf_text=f"{alinan}+{hediye}",
                    net_birim_maliyet=kademe_net,
                    net_birim_maliyet_kdvli=kademe_kdvli,
                    toplam_iskonto_yuzdesi=mf_isk_yuzde
                ))

                if kademe_net < en_iyi_net:
                    en_iyi_net = kademe_net
                    en_iyi_alinan = alinan
                    en_iyi_hediye = hediye
                    en_iyi_mf_isk = mf_isk_yuzde
        else:
            # MF yoksa tek kademe
            en_iyi_net = round(dsf * isk_carpan, 2)

        en_iyi_kdvli = round(en_iyi_net * (1.0 + (kdv_orani / 100.0)), 2)
        toplam_iskonto = round((1.0 - (en_iyi_net / dsf)) * 100.0, 2) if dsf > 0 else 0.0

        return MaliyetDetayi(
            dsf=round(dsf, 2),
            psf=round(psf, 2),
            kdv_orani=kdv_orani,
            mf_metni=mf_str,
            alinan_adet=en_iyi_alinan,
            mf_adet=en_iyi_hediye,
            mf_iskonto_orani=en_iyi_mf_isk,
            ticari_iskonto_orani=round(ticari_iskonto, 2),
            toplam_iskonto_orani=toplam_iskonto,
            net_birim_maliyet=round(en_iyi_net, 2),
            net_birim_maliyet_kdvli=round(en_iyi_kdvli, 2),
            vade_gun=vade_gun,
            kademeler=kademeler
        )
