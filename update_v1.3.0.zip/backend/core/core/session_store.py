import os
import json
from pathlib import Path
from typing import Optional, Dict, Any

SESSIONS_DIR = Path(__file__).resolve().parent.parent / "sessions"
SESSIONS_DIR.mkdir(parents=True, exist_ok=True)

class SessionStore:
    @staticmethod
    def get_session_file(depo_name: str) -> Path:
        return SESSIONS_DIR / f"{depo_name.lower()}_state.json"

    @classmethod
    def exists(cls, depo_name: str) -> bool:
        path = cls.get_session_file(depo_name)
        return path.exists() and path.stat().st_size > 10

    @classmethod
    def save_state(cls, depo_name: str, state_data: Dict[str, Any]):
        path = cls.get_session_file(depo_name)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(state_data, f, ensure_ascii=False, indent=2)

    @classmethod
    def load_state(cls, depo_name: str) -> Optional[Dict[str, Any]]:
        path = cls.get_session_file(depo_name)
        if not path.exists():
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    @classmethod
    def clear(cls, depo_name: str):
        path = cls.get_session_file(depo_name)
        if path.exists():
            try:
                os.remove(path)
            except OSError:
                pass
