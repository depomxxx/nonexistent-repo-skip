# -*- coding: utf-8 -*-
"""
backend/license_manager.py
--------------------------
Eczane Depo Pro - Ticari Lisanslama, Üye Eczacı Kayıt ve Abonelik Doğrulama Motoru.

MİMARİ (Çift Katmanlı Güvenlik):
1. Kriptografik İmzalı Lisans Anahtarı (Offline + Online):
   - Lisans anahtarı; Eczane Adı, Eczacı Adı Soyadı, Telefon, GLN, Bitiş Tarihi (YYYY-MM-DD),
     PC Limiti ve Donanım Kimliği (HWID) bilgilerini HMAC-SHA256 imzası ile barındırır.
   - Eczanede internet kesilse bile imza ve bitiş tarihi yerel olarak doğrulanır.
2. Üye Eczane Bilgi Kaydı (CRM):
   - Kurulum veya aktivasyon sırasında Eczane Adı, Eczacı Adı Soyadı, Telefon ve Şehir bilgileri
     kayıt altına alınır.
"""

import os
import sys
import json
import hmac
import base64
import hashlib
import socket
import uuid
import datetime
from typing import Dict, Any, Optional

# Sadece geliştirici (Admin) lisans üreticide tam karşılığı bulunan doğrulama anahtarı
_MASTER_VERIFY_SALT = b"EczaneDepoPro_Commercial_v1_MasterKey_2026_!#987"


class LicenseManager:
    def __init__(self, base_dir: Optional[str] = None):
        if base_dir:
            self.base_dir = base_dir
        else:
            if getattr(sys, "frozen", False):
                self.base_dir = os.path.dirname(os.path.abspath(sys.executable))
            else:
                self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        self.license_file = os.path.join(self.base_dir, "license.json")

    def get_hardware_id(self) -> str:
        """Bu bilgisayarın benzersiz donanım kimliğini (HWID) üretir (XXXX-XXXX-XXXX)."""
        raw_id = ""
        if sys.platform == "win32":
            try:
                import subprocess
                out = subprocess.check_output(
                    "wmic csproduct get uuid",
                    shell=True,
                    stderr=subprocess.DEVNULL
                ).decode("utf-8", errors="ignore")
                lines = [ln.strip() for ln in out.splitlines() if ln.strip() and "UUID" not in ln.upper()]
                if lines:
                    raw_id = lines[0]
            except Exception:
                pass
        if not raw_id:
            raw_id = f"{socket.gethostname()}-{uuid.getnode()}"
        digest = hashlib.sha256(raw_id.encode("utf-8")).hexdigest().upper()
        return f"{digest[0:4]}-{digest[4:8]}-{digest[8:12]}"

    @staticmethod
    def generate_license_key(
        pharmacy_name: str,
        gln_no: str = "",
        expires_at: str = "2027-12-31",
        max_pcs: int = 10,
        hwid_lock: str = "ANY",
        plan: str = "PRO_YILLIK",
        pharmacist_name: str = "",
        phone: str = "",
        city: str = ""
    ) -> str:
        """
        Yönetici (Admin) için kriptografik imzalı lisans anahtarı üretir.
        Format: EDP-<BASE64URL_PAYLOAD>.<HMAC_IMZA_16>
        """
        clean_exp = expires_at.strip().replace("/", "-")
        payload_dict = {
            "e": pharmacy_name.strip().upper()[:40],
            "fn": pharmacist_name.strip()[:40],
            "tel": phone.strip()[:20],
            "ct": city.strip().upper()[:25],
            "g": gln_no.strip()[:20],
            "x": clean_exp,
            "m": int(max_pcs),
            "h": (hwid_lock or "ANY").strip().upper(),
            "p": plan.strip().upper(),
        }
        payload_json = json.dumps(payload_dict, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        b64_payload = base64.urlsafe_b64encode(payload_json).decode("ascii").rstrip("=")
        sig = hmac.new(_MASTER_VERIFY_SALT, b64_payload.encode("ascii"), hashlib.sha256).hexdigest().upper()[:16]
        return f"EDP-{b64_payload}.{sig}"

    def verify_license_key(self, key_str: str) -> Dict[str, Any]:
        """Verilen lisans anahtarının kriptografik imzasını, donanım kilidini ve süresini doğrular."""
        clean_key = (key_str or "").strip()
        if not clean_key.startswith("EDP-") or "." not in clean_key:
            return {"valid": False, "message": "Geçersiz lisans anahtarı formatı (EDP-... ile başlamalıdır)."}

        try:
            body_part = clean_key[4:]
            b64_payload, given_sig = body_part.rsplit(".", 1)
            expected_sig = hmac.new(
                _MASTER_VERIFY_SALT,
                b64_payload.encode("ascii"),
                hashlib.sha256
            ).hexdigest().upper()[:16]

            if not hmac.compare_digest(given_sig.upper(), expected_sig):
                return {"valid": False, "message": "Lisans imzası geçersiz veya değiştirilmiş!"}

            pad = "=" * ((4 - len(b64_payload) % 4) % 4)
            payload_bytes = base64.urlsafe_b64decode((b64_payload + pad).encode("ascii"))
            data = json.loads(payload_bytes.decode("utf-8"))

            pharmacy_name = data.get("e", "ECZANE")
            pharmacist_name = data.get("fn", "")
            phone = data.get("tel", "")
            city = data.get("ct", "")
            gln_no = data.get("g", "")
            expires_at = data.get("x", "2027-12-31")
            max_pcs = int(data.get("m", 10))
            hwid_lock = data.get("h", "ANY")
            plan = data.get("p", "PRO_YILLIK")

            my_hwid = self.get_hardware_id()
            if hwid_lock and hwid_lock != "ANY" and hwid_lock != my_hwid:
                return {
                    "valid": False,
                    "message": f"Bu lisans başka bir bilgisayara ({hwid_lock}) tanımlanmış. Bu PC HWID: {my_hwid}"
                }

            exp_date = datetime.date.fromisoformat(expires_at)
            today = datetime.date.today()
            days_left = (exp_date - today).days

            if days_left < 0:
                return {
                    "valid": False,
                    "expired": True,
                    "pharmacy_name": pharmacy_name,
                    "pharmacist_name": pharmacist_name,
                    "phone": phone,
                    "city": city,
                    "expires_at": expires_at,
                    "days_left": days_left,
                    "message": f"Lisans süreniz {expires_at} tarihinde dolmuştur. Lütfen lisansınızı yenileyin."
                }

            return {
                "valid": True,
                "expired": False,
                "pharmacy_name": pharmacy_name,
                "pharmacist_name": pharmacist_name,
                "phone": phone,
                "city": city,
                "gln_no": gln_no,
                "expires_at": expires_at,
                "days_left": days_left,
                "max_pcs": max_pcs,
                "hwid_lock": hwid_lock,
                "my_hwid": my_hwid,
                "plan": plan,
                "license_key": clean_key,
                "message": f"Lisans Aktif ({pharmacy_name} - Kalan Süre: {days_left} gün)"
            }
        except Exception as e:
            return {"valid": False, "message": f"Lisans anahtarı çözümlenemedi: {str(e)}"}

    def ensure_default_license(self) -> Dict[str, Any]:
        """Kurulu sistemde henüz license.json yoksa mevcut eczane için varsayılan aktif lisansı oluşturur."""
        if os.path.isfile(self.license_file):
            try:
                with open(self.license_file, "r", encoding="utf-8") as f:
                    saved = json.load(f)
                key = saved.get("license_key", "")
                if key:
                    res = self.verify_license_key(key)
                    res["activated_at"] = saved.get("activated_at", "")
                    if saved.get("pharmacist_name"):
                        res["pharmacist_name"] = saved["pharmacist_name"]
                    if saved.get("phone"):
                        res["phone"] = saved["phone"]
                    if saved.get("city"):
                        res["city"] = saved["city"]
                    return res
            except Exception:
                pass

        tria_user = os.environ.get("TRIA_DB_USER", "EDA").strip().upper()
        if tria_user == "ARASTIRMA":
            default_pharmacy = "ARAŞTIRMA ECZANESİ"
        elif tria_user == "EDA":
            default_pharmacy = "EDA ECZANESİ"
        else:
            default_pharmacy = f"{tria_user} ECZANESİ"

        default_key = self.generate_license_key(
            pharmacy_name=default_pharmacy,
            gln_no="8680001000000",
            expires_at="2027-12-31",
            max_pcs=15,
            hwid_lock="ANY",
            plan="KURUMSAL_SINIRSIZ"
        )
        self.activate_license(default_key)
        return self.verify_license_key(default_key)

    def activate_license(
        self,
        key_str: str,
        pharmacist_name: str = "",
        phone: str = "",
        city: str = ""
    ) -> Dict[str, Any]:
        """Lisans anahtarını doğrular ve üye eczacı iletişim bilgileriyle birlikte license.json'a kaydeder."""
        check = self.verify_license_key(key_str)
        if not check.get("valid"):
            return check

        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        final_pharmacist = pharmacist_name.strip() or check.get("pharmacist_name", "")
        final_phone = phone.strip() or check.get("phone", "")
        final_city = city.strip() or check.get("city", "")

        save_data = {
            "license_key": key_str.strip(),
            "pharmacy_name": check["pharmacy_name"],
            "pharmacist_name": final_pharmacist,
            "phone": final_phone,
            "city": final_city,
            "gln_no": check.get("gln_no", ""),
            "expires_at": check["expires_at"],
            "max_pcs": check.get("max_pcs", 10),
            "hwid_lock": check.get("hwid_lock", "ANY"),
            "plan": check.get("plan", "PRO_YILLIK"),
            "activated_at": now_str,
            "my_hwid": self.get_hardware_id(),
            "pc_name": socket.gethostname()
        }
        try:
            with open(self.license_file, "w", encoding="utf-8") as f:
                json.dump(save_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            return {"valid": False, "message": f"Lisans dosyası kaydedilemedi: {str(e)}"}

        check["activated_at"] = now_str
        check["pharmacist_name"] = final_pharmacist
        check["phone"] = final_phone
        check["city"] = final_city
        return check

    def get_status(self) -> Dict[str, Any]:
        """Mevcut lisans durumunu ve bu bilgisayarın HWID bilgisini döndürür."""
        info = self.ensure_default_license()
        info["my_hwid"] = self.get_hardware_id()
        info["pc_name"] = socket.gethostname()
        return info


license_manager = LicenseManager()
