# -*- coding: utf-8 -*-
"""
E-Ticaret & Piyasa Perakende Fiyat Kıyaslama Motoru
Trendyol, Hepsiburada, Sachane, Dermoeczanem, Dermokozmetika,
Kırmızıbeyaz, Dermojet, Kozvit ve Daffne platformlarını tarar
ve depo alış maliyetleriyle karşılaştırır.
"""

import asyncio
import json
import logging
import re
from typing import List, Optional, Tuple, Dict, Any, Set
from urllib.parse import quote, urljoin

from bs4 import BeautifulSoup
from curl_cffi import requests

from .models import MarketPlatform, RetailProductOffer, DepoOzetFiyat, MarketPriceReport

logger = logging.getLogger("market_engine")
logger.setLevel(logging.INFO)

PLATFORM_META = {
    MarketPlatform.TRENDYOL: {
        "adi": "Trendyol",
        "domain": "trendyol.com",
        "renk": "orange",
    },
    MarketPlatform.HEPSIBURADA: {
        "adi": "Hepsiburada",
        "domain": "hepsiburada.com",
        "renk": "amber",
    },
    MarketPlatform.SACHANE: {
        "adi": "Sachane",
        "domain": "sachane.com",
        "renk": "pink",
    },
    MarketPlatform.DERMOECZANEM: {
        "adi": "Dermoeczanem",
        "domain": "dermoeczanem.com",
        "renk": "emerald",
    },
    MarketPlatform.DERMOKOZMETIKA: {
        "adi": "Dermokozmetika",
        "domain": "dermokozmetika.com.tr",
        "renk": "indigo",
    },
    MarketPlatform.KIRMIZIBEYAZ: {
        "adi": "Kırmızıbeyaz",
        "domain": "kirmizibeyazz.com",
        "renk": "rose",
    },
    MarketPlatform.DERMOJET: {
        "adi": "Dermojet",
        "domain": "dermojet.com.tr",
        "renk": "cyan",
    },
    MarketPlatform.KOZVIT: {
        "adi": "Kozvit",
        "domain": "kozvit.com",
        "renk": "purple",
    },
    MarketPlatform.DAFFNE: {
        "adi": "Daffne",
        "domain": "daffne.com",
        "renk": "teal",
    },
}

DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept-Language": "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7",
}


def _clean_price(price_str: Any) -> float:
    """Metin veya sayı formatındaki fiyatı float TL'ye çevirir."""
    if price_str is None:
        return 0.0
    if isinstance(price_str, (int, float)):
        return round(float(price_str), 2)
    s = str(price_str).replace("TL", "").replace("₺", "").replace("TRY", "").strip()
    m = re.search(r"([\d\.,]+)", s)
    if not m:
        return 0.0
    val_str = m.group(1)
    if "," in val_str and "." in val_str:
        val_str = val_str.replace(".", "").replace(",", ".")
    elif "," in val_str:
        val_str = val_str.replace(",", ".")
    try:
        return round(float(val_str), 2)
    except Exception:
        return 0.0


# ---------------------------------------------------------
# Akıllı Ürün Doğrulama & İlgililik Filtresi (Smart Matcher)
# ---------------------------------------------------------

def normalize_tr(s: str) -> str:
    """Türkçe karakterleri ve noktalama işaretlerini standartlaştırır."""
    if not s:
        return ""
    # Önce büyük harfli Türkçe karakterleri dönüştür (Python .lower()'ın İ -> i\u0307 yapmasını önler)
    tr_upper = {'İ': 'i', 'I': 'i', 'Ğ': 'g', 'Ü': 'u', 'Ş': 's', 'Ö': 'o', 'Ç': 'c'}
    for k, v in tr_upper.items():
        s = s.replace(k, v)
    s = s.lower()
    s = s.replace('\u0307', '')
    tr_lower = {'ı': 'i', 'ğ': 'g', 'ü': 'u', 'ş': 's', 'ö': 'o', 'ç': 'c'}
    for k, v in tr_lower.items():
        s = s.replace(k, v)
    return s


def normalize_comp(s: str) -> str:
    """Karşılaştırmalar için tire, slaş, artı vb. sembolleri boşluğa çevirip sadeleştirir."""
    s = normalize_tr(s)
    s = re.sub(r'[\-_/\\+]', ' ', s)
    s = re.sub(r'\s+', ' ', s)
    return s.strip()


KNOWN_BRANDS = [
    ("la roche posay", ["la roche posay", "la roche-posay", "la roche", "lrp"]),
    ("bioderma", ["bioderma"]),
    ("cerave", ["cerave"]),
    ("avene", ["avene", "eau thermale avene"]),
    ("vichy", ["vichy"]),
    ("bepanthol", ["bepanthol"]),
    ("solgar", ["solgar"]),
    ("ocean", ["ocean", "orzax ocean", "orzax"]),
    ("venatura", ["venatura", "ve natura"]),
    ("ducray", ["ducray"]),
    ("svr", ["svr", "laboratoires svr"]),
    ("darphin", ["darphin"]),
    ("mustela", ["mustela"]),
    ("sebamed", ["sebamed"]),
    ("nuxe", ["nuxe"]),
    ("supradyn", ["supradyn"]),
    ("pharmaton", ["pharmaton"]),
    ("purest solutions", ["the purest solutions", "the purest", "purest solutions"]),
    ("babe", ["laboratorios babe", "babe"]),
    ("cosmed", ["cosmed"]),
    ("uriage", ["uriage"]),
    ("cumlaude", ["cumlaude lab", "cumlaude"]),
    ("day2day", ["day2day", "day 2 day"]),
    ("dynavit", ["dynavit"]),
    ("sambucol", ["sambucol"]),
    ("voonka", ["voonka"]),
    ("newvit", ["newvit"]),
    ("liposomal", ["liposomal"]),
    ("ester c", ["ester-c", "ester c"]),
    ("dentaver", ["dentaver"]),
    ("sensodyne", ["sensodyne"]),
    ("parodontax", ["parodontax"]),
    ("marvis", ["marvis"]),
    ("curaprox", ["curaprox"]),
    ("roche", ["roche"]),
    ("bayer", ["bayer"]),
    ("abdi ibrahim", ["abdi ibrahim"]),
]

KNOWN_SERIES = [
    # La Roche Posay
    "effaclar", "anthelios", "cicaplast", "lipikar", "toleriane", "hyalu", "pure vitamin", "retinol b3", "kerium",
    # Bioderma
    "sebium", "sensibio", "atoderm", "hydrabio", "photoderm", "cicabio", "node", "pigmentbio",
    # Avene
    "cicalfate", "cleanance", "xeracalm", "hydrance", "tolerance", "a-oxitive", "sunsimed",
    # Vichy
    "dercos", "mineral 89", "liftactiv", "neovadiol", "normaderm", "capital soleil",
    # CeraVe
    "blemish", "sa smoothing",
]

# ---------------------------------------------------------
# Dermokozmetik Renkli / Ton / Faktör / Alt Model Ayrıştırma
# ---------------------------------------------------------

EXPLICIT_TINTED_KEYWORDS = [
    "renkli", "tinted", "teinte", "teintee", "teinted", "unifiant",
    "bb krem", "cc krem", "renklendirici", "dore", "bronze",
    "acik ton", "orta ton", "koyu ton", "colored", "coloured"
]

UNTINTED_KEYWORDS = [
    "renksiz", "gorunmez", "invisible", "sans teinte", "non teinte", "untinted",
    "transparan", "transparent", "clear"
]

SHADE_GROUPS = {
    "light": ["light", "clair", "acik ton"],
    "medium": ["medium", "orta ton"],
    "dore": ["dore", "golden", "altin"],
    "bronze": ["bronze", "bronz"],
    "dark": ["koyu ton", "fonce", "deep"],
}

SUNSCREEN_HINTS = [
    "gunes", "sun", "solar", "solair", "spf", "uvmune", "anthelios",
    "photoderm", "capital soleil", "sunsimed", "bariesun"
]

MUTUALLY_EXCLUSIVE_SUBMODELS = [
    # Leke karşıtı / Pigment
    ("dark spots", ["dark spots", "anti dark spots", "leke karsiti", "pigmentbio", "spot age", "mela b3", "melasyl", "clairial"]),
    # Yaşlanma / Kırışıklık / Anti-age
    ("age correct", ["age correct", "anti age", "kirisiklik", "neovadiol", "liftactiv", "hyalu b5", "retinol b3"]),
    # Yağ kontrolü / Parlama karşıtı / Mat
    ("oil control", ["oil control", "dry touch", "anti shine", "matlastirici", "sebo", "mat control", "sebium mat"]),
    # Mineral güneş koruyucu
    ("mineral one", ["mineral one", "mineral 100", "nude touch", "cover touch"]),
    # Hassasiyet / Kızarıklık / AR
    ("ar redness", ["sensibio ar", "rosaliac", "kizariklik", "anti redness"]),
    # Yoğun onarıcı / Yatıştırıcı
    ("cicaplast", ["cicaplast"]),
    ("cicalfate", ["cicalfate"]),
    # Akne / Kusur bakım alt modelleri
    ("duo", ["effaclar duo", "duo+", "duo m"]),
    ("effaclar mat", ["effaclar mat"]),
    ("effaclar k", ["effaclar k"]),
    ("effaclar h", ["effaclar h", "iso biome", "isobiome"]),
    ("pore refiner", ["pore refiner"]),
    ("sebium global", ["sebium global"]),
    ("sebium sensitive", ["sebium sensitive"]),
    ("comedomed", ["comedomed"]),
]

CRITICAL_SUBMODELS = [
    "anti-dark spots", "dark spots", "age correct", "oil control",
    "dry touch", "anti-shine", "invisible", "mineral one", "pigment correct",
    "duo", "mat", "sensitive", "kerato", "hydra", "iso-biome", "pore refiner",
    "baume", "global", "night", "intensive", "protect", "unifiant",
    "h2o", "gel moussant", "cleanser", "lotion"
]

FORMS = ["serum", "tonik", "stick", "sprey", "patch", "peeling", "jel", "krem", "losyon", "kopuk", "balm", "sampuan", "yag"]


def extract_shade(text: str) -> Optional[str]:
    """Ürünün renk tonunu (Light, Medium, Dore vb.) tespit eder."""
    t = normalize_comp(text)
    if "dark spot" in t:
        t = t.replace("dark spot", " ")
    for shade, aliases in SHADE_GROUPS.items():
        for al in aliases:
            if re.search(r'\b' + re.escape(al) + r'\b', t):
                return shade
    return None


def extract_spf(text: str) -> Optional[int]:
    """Metindeki SPF güneş koruma faktörünü (örn: SPF 50, 30, 20) ayrıştırır."""
    t = normalize_comp(text)
    m = re.search(r'\bspf\s*([0-9]{2,3})\b', t)
    if not m:
        m = re.search(r'\b([0-9]{2,3})\s*spf\b', t)
    if m:
        try:
            val = int(m.group(1))
            if val in (10, 15, 20, 25, 30, 40, 50, 60, 80, 100):
                return val
        except Exception:
            pass
    if re.search(r'\b50\s*plus\b|\b50\s*\+', text.lower()):
        return 50
    return None


def check_color_and_shade(t_text: str, o_text: str) -> Tuple[bool, str]:
    """Dermokozmetik renkli (tinted) vs renksiz (untinted) ve ton (light/medium/dore) ayrımını denetler."""
    t_norm = normalize_comp(t_text)
    o_norm = normalize_comp(o_text)
    
    t_shade = extract_shade(t_norm)
    o_shade = extract_shade(o_norm)
    
    t_has_explicit_tint = any(k in t_norm for k in EXPLICIT_TINTED_KEYWORDS)
    o_has_explicit_tint = any(k in o_norm for k in EXPLICIT_TINTED_KEYWORDS)
    t_has_untinted = any(k in t_norm for k in UNTINTED_KEYWORDS)
    o_has_untinted = any(k in o_norm for k in UNTINTED_KEYWORDS)

    # Hedef renkli mi?
    target_is_tinted = (t_has_explicit_tint or (t_shade is not None and t_shade not in ('light',))) and not t_has_untinted
    if t_shade == 'light' and (t_has_explicit_tint or any(w in t_norm for w in ['gunes', 'sun', 'spf', 'uvmune', 'touch', 'mineral', 'fluid'])):
        target_is_tinted = True

    # Teklif renkli mi?
    offer_is_tinted = (o_has_explicit_tint or (o_shade is not None and o_shade not in ('light',))) and not o_has_untinted
    if o_shade == 'light' and (o_has_explicit_tint or any(w in o_norm for w in ['gunes', 'sun', 'spf', 'uvmune', 'touch', 'mineral', 'fluid'])):
        offer_is_tinted = True

    # 1. Hedef standart/renksiz iken teklif renkli ise REDDET
    if not target_is_tinted and offer_is_tinted:
        return False, "Renk uyuşmazlığı: Hedef standart/renksiz ürün iken teklif renkli (tinted) versiyon"

    # 2. Hedef renkli iken teklif renksiz/standart ise REDDET
    if target_is_tinted:
        if o_has_untinted or not offer_is_tinted:
            return False, "Renk uyuşmazlığı: Hedef renkli ürün iken teklif renksiz/standart versiyon"
        # Ton kontrolü
        if t_shade and o_shade and t_shade != o_shade:
            return False, f"Ton uyuşmazlığı: Hedef ton ({t_shade}) != Teklif ton ({o_shade})"

    return True, "Renk uyumlu"


def check_spf_distinction(t_text: str, o_text: str) -> Tuple[bool, str]:
    """Güneş koruma faktörü (SPF 50 vs 30 vs Korumasız) ayrımını denetler."""
    t_norm = normalize_comp(t_text)
    o_norm = normalize_comp(o_text)
    t_spf = extract_spf(t_text)
    o_spf = extract_spf(o_text)
    
    # Her ikisinde de faktör varsa farklıysa REDDET
    if t_spf is not None and o_spf is not None:
        if t_spf != o_spf:
            return False, f"SPF koruma faktörü uyuşmazlığı: Hedef SPF {t_spf} != Teklif SPF {o_spf}"
            
    # Hedef korumasız günlük ürün iken teklif SPF'li ise REDDET (Örn: Duo vs Duo SPF30)
    target_is_sunscreen = any(w in t_norm for w in SUNSCREEN_HINTS)
    if t_spf is None and o_spf is not None and not target_is_sunscreen:
        return False, f"Faktör uyuşmazlığı: Hedef güneş korumasız ürün iken teklif SPF {o_spf} içeriyor"
        
    # Hedef SPF belirtmiş ama teklifte SPF yoksa REDDET
    if t_spf is not None and o_spf is None and not any(w in o_norm for w in SUNSCREEN_HINTS):
        return False, f"Faktör uyuşmazlığı: Hedef SPF {t_spf} korumalı iken teklifte SPF koruması yok"
        
    return True, "SPF uyumlu"


def check_submodel_distinction(t_text: str, o_text: str) -> Tuple[bool, str]:
    """Birbirini dışlayan kritik dermokozmetik alt modelleri (Dark spots vs Age correct vs Oil control vb.) denetler."""
    t_norm = normalize_comp(t_text)
    o_norm = normalize_comp(o_text)
    
    t_found = []
    o_found = []
    for tag, aliases in MUTUALLY_EXCLUSIVE_SUBMODELS:
        if any(a in t_norm for a in aliases):
            t_found.append(tag)
        if any(a in o_norm for a in aliases):
            o_found.append(tag)
            
    if t_found:
        if not any(tag in o_found for tag in t_found):
            return False, f"Alt model uyuşmazlığı: Hedef '{t_found[0]}' iken teklifte bu model yok"
        conflicts = [tag for tag in o_found if tag not in t_found]
        if conflicts:
            return False, f"Alt model uyuşmazlığı: Hedef '{t_found[0]}' iken teklif farklı model içeriyor ({conflicts[0]})"
    else:
        if o_found:
            return False, f"Alt model uyuşmazlığı: Hedef standart ürün iken teklif özel alt model içeriyor ({o_found[0]})"
            
    return True, "Alt model uyumlu"


def extract_brand(text: str) -> Optional[str]:
    """Bilinen markalardan birini metin içinde tespit eder."""
    t = normalize_tr(text)
    for canonical, aliases in KNOWN_BRANDS:
        for alias in aliases:
            pattern = r'(?<![a-z0-9])' + re.escape(alias) + r'(?![a-z0-9])'
            if re.search(pattern, t):
                return canonical
    return None


def extract_specs(text: str) -> Dict[str, Set[float]]:
    """Ürün hacim (ml), dozaj (mg/g) ve adet/kapsül sayılarını ayrıştırır."""
    t = normalize_tr(text)
    specs: Dict[str, Set[float]] = {"ml": set(), "g": set(), "mg": set(), "cnt": set()}
    
    # 1. ml / litre
    for val in re.findall(r'(\d+[\.,]?\d*)\s*(?:ml|mililitre)\b', t):
        try:
            specs["ml"].add(float(val.replace(',', '.')))
        except Exception:
            pass
    for val in re.findall(r'(\d+[\.,]?\d*)\s*(?:lt|litre)\b', t):
        try:
            specs["ml"].add(float(val.replace(',', '.')) * 1000)
        except Exception:
            pass
        
    # 2. mg / mcg / gram
    for val in re.findall(r'(\d+[\.,]?\d*)\s*(?:mg|miligram)\b', t):
        try:
            specs["mg"].add(float(val.replace(',', '.')))
        except Exception:
            pass
    for val in re.findall(r'(\d+[\.,]?\d*)\s*(?:mcg|mikrogram)\b', t):
        try:
            specs["mg"].add(float(val.replace(',', '.')) / 1000.0)
        except Exception:
            pass
    for val in re.findall(r'(\d+[\.,]?\d*)\s*(?:g|gr|gram)\b', t):
        try:
            specs["g"].add(float(val.replace(',', '.')))
        except Exception:
            pass
    for val in re.findall(r'(\d+[\.,]?\d*)\s*(?:kg|kilogram)\b', t):
        try:
            specs["g"].add(float(val.replace(',', '.')) * 1000)
        except Exception:
            pass
        
    # 3. Kutu / Adet / Kapsül / Tablet sayısı
    for val in re.findall(r'(\d+)\s*(?:kapsul|tablet|tb|cap|kaps|sase|flakon)\b', t):
        try:
            specs["cnt"].add(float(val))
        except Exception:
            pass
        
    return {k: v for k, v in specs.items() if v}


def is_bundle_or_multipack(text: str) -> bool:
    """Çoklu paket, set veya promosyon kofrelerini tespit eder."""
    t = normalize_tr(text)
    patterns = [
        r'\b\d+\s*[\'\-]?\s*(?:li|lu|lü)\b',
        r'(?:\b|[a-z0-9])x\s*[2-9]\b',
        r'\b[2-9]\s*x\b',
        r'\b(?:paket|set|kofre|canta|hediye|hediyeli|ikili|uclu|dortlu|avantaj)\b',
        r'\b[2-9]\s*adet\b',
        r'\b(?:1\s*alana|2\.\s*urun|alana\s*2\.)\b',
    ]
    for p in patterns:
        if re.search(p, t):
            return True
    return False


def clean_catalog_search_term(catalog_name: str) -> str:
    """Pazaryeri aramaları için katalog ismindeki gürültüleri temizler ve odaklı kelimeleri seçer."""
    s = re.sub(r'\(.*?\)', ' ', catalog_name)
    s = re.sub(r'(?i)%[0-9]+\s*(?:indirimli|iskonto|firsat)|hediyeli|promosyon', ' ', s)
    s = re.sub(r'[\+\*\/\\]', ' ', s)
    s = s.replace('-', ' ')
    s = normalize_tr(s)
    tokens = [w for w in s.split() if len(w) > 1 and w not in ('spf',)]
    return " ".join(tokens[:7]).strip()


def is_strictly_relevant(offer_title: str, target_name: str) -> Tuple[bool, str]:
    """
    Pazaryeri teklifinin aranan ürün ile birebir aynı ürün olup olmadığını sıkı denetler.
    Marka, ürün serisi, kritik alt model, ölçü (ml/mg) ve paket büyüklüğünü karşılaştırır.
    """
    t_clean = normalize_tr(target_name)
    o_clean = normalize_tr(offer_title)
    
    # 1. Marka Kontrolü
    t_brand = extract_brand(t_clean)
    o_brand = extract_brand(o_clean)
    if t_brand and o_brand and t_brand != o_brand:
        return False, f"Marka uyuşmazlığı: Hedef '{t_brand}' != Teklif '{o_brand}'"
    
    # 2. Multi-pack / Bundle Kontrolü
    target_is_bundle = is_bundle_or_multipack(t_clean)
    offer_is_bundle = is_bundle_or_multipack(o_clean)
    if not target_is_bundle and offer_is_bundle:
        return False, "Tekil ürüne çoklu paket/set teklifi elendi"
    
    # 3. Hacim / Dozaj / Adet Kontrolü (Spesifikasyon Kontrolü)
    t_specs = extract_specs(t_clean)
    o_specs = extract_specs(o_clean)
    
    # 3a. Fiziksel birim uyuşmazlığı (sıvı/krem ml iken tablet/kapsül/bant/patch olamaz)
    if "ml" in t_specs and "cnt" not in t_specs:
        if "cnt" in o_specs and "ml" not in o_specs:
            return False, "Fiziksel form uyuşmazlığı: Hedef ml iken teklif adet/bant/kapsül"
    if "cnt" in t_specs and "ml" not in t_specs:
        if "ml" in o_specs and "cnt" not in o_specs:
            return False, "Fiziksel form uyuşmazlığı: Hedef tablet/kapsül iken teklif ml/sıvı"
    
    # 3b. Hedef tek bir ölçü belirtiyorsa teklifte birden fazla farklı ölçü (örn: 500ml + 200ml set) olamaz
    for unit, t_vals in t_specs.items():
        if len(t_vals) == 1 and unit in o_specs and len(o_specs[unit]) > 1:
            return False, f"Birden fazla hacim içeren set/paket teklifi elendi ({o_specs[unit]})"

    # 3c. Değer eşleşmesi
    for unit, t_vals in t_specs.items():
        if unit in o_specs:
            o_vals = o_specs[unit]
            if not t_vals.intersection(o_vals):
                return False, f"Ölçü uyuşmazlığı ({unit}): Hedef {t_vals} != Teklif {o_vals}"

    # 4. Seri / Seri Altı Kontrolü (Örn: Effaclar vs Anthelios vs Sebium)
    t_series = [s for s in KNOWN_SERIES if s in t_clean]
    o_series = [s for s in KNOWN_SERIES if s in o_clean]
    if t_series and o_series:
        if not set(t_series).intersection(set(o_series)):
            return False, f"Seri uyuşmazlığı: Hedef '{t_series[0]}' != Teklif '{o_series[0]}'"
    elif t_series and not o_series:
        if any(s in t_series for s in ["effaclar", "sebium", "sensibio", "anthelios", "cicaplast", "lipikar", "atoderm", "toleriane"]):
            return False, f"Seri uyuşmazlığı: Hedef '{t_series[0]}' teklifte yok"
    
    # 4b. Renkli (Tinted) vs Renksiz (Untinted) ve Ton Ayrımı
    color_ok, color_reason = check_color_and_shade(target_name, offer_title)
    if not color_ok:
        return False, color_reason

    # 4c. Güneş Koruma Faktörü (SPF) Ayrımı
    spf_ok, spf_reason = check_spf_distinction(target_name, offer_title)
    if not spf_ok:
        return False, spf_reason

    # 4d. Kritik Dermokozmetik Alt Model & Varyant Ayrımı
    submodel_ok, submodel_reason = check_submodel_distinction(target_name, offer_title)
    if not submodel_ok:
        return False, submodel_reason

    # 5. Kritik Model Kelimeleri (Örn: "Duo" vs "Mat")
    t_comp = normalize_comp(target_name)
    o_comp = normalize_comp(offer_title)
    for m in CRITICAL_SUBMODELS:
        m_comp = normalize_comp(m)
        if m_comp in t_comp and m_comp not in o_comp:
            return False, f"Model kelimesi '{m}' teklifte yok"
        if m_comp in o_comp and m_comp not in t_comp and any(normalize_comp(alt) in t_comp for alt in CRITICAL_SUBMODELS if alt != m):
            return False, f"Farklı model: Teklif '{m}' modelini içeriyor"

    # 6. Form / Tip Kontrolü (serum, tonik, stick, patch, bant, sampuan vb.)
    FORMAT_KEYWORDS = [
        "serum", "tonik", "stick", "sprey", "patch", "bant", "bandi",
        "maske", "mendil", "sampuan", "sabun", "peeling"
    ]
    for fmt in FORMAT_KEYWORDS:
        if fmt in o_clean and fmt not in t_clean:
            return False, f"Farklı ürün formatı: Teklif '{fmt}' içeriyor"

    # 6b. Temizleme / Yıkama jeli ayrımı (Hedef bakım ürünü iken teklif yıkama jeli/köpük olamaz)
    CLEANSER_KEYWORDS = ["temizleme jeli", "yikama jeli", "kopuren jel", "gel moussant", "temizleme suyu", "temizleme kopugu"]
    target_is_cleanser = any(w in t_clean for w in CLEANSER_KEYWORDS)
    offer_is_cleanser = any(w in o_clean for w in CLEANSER_KEYWORDS)
    if not target_is_cleanser and offer_is_cleanser:
        return False, "Farklı ürün tipi: Teklif yıkama/temizleme jeli formunda"
            
    # 7. Kelime Kapsama Kontrolü (Genel Ürünler / İlaçlar İçin)
    stop_words = {"mg", "ml", "tb", "kapsul", "tablet", "adet", "icin", "ve", "ile", "plus", "cap", "gr", "krem", "jel", "bakim", "yuz", "cilt"}
    target_words = [w for w in re.findall(r'[a-zA-Z0-9]+', t_clean) if len(w) > 2 and w not in stop_words]
    if target_words:
        first_key = target_words[0]
        if first_key not in o_clean:
            if not (t_brand and t_brand in o_clean):
                return False, f"Anahtar kelime '{first_key}' teklifte yok"
        
        matches = sum(1 for w in target_words if w in o_clean)
        min_required = max(1, min(2, len(target_words)))
        if matches < min_required:
            return False, f"Yetersiz kelime eşleşmesi ({matches}/{min_required})"
            
    return True, "Uyuşuyor"



# ---------------------------------------------------------
# Platform Scrapers (Synchronous Worker Functions)
# ---------------------------------------------------------

def scrape_trendyol(query: str, max_items: int = 15) -> List[RetailProductOffer]:
    offers: List[RetailProductOffer] = []
    meta = PLATFORM_META[MarketPlatform.TRENDYOL]
    url = f"https://www.trendyol.com/sr?q={quote(query)}"
    try:
        r = requests.get(url, impersonate="chrome124", headers=DEFAULT_HEADERS, timeout=10)
        if r.status_code != 200:
            return offers
        
        marker = '__single-search-result__PROPS"]='
        idx = r.text.find(marker)
        if idx != -1:
            start = idx + len(marker)
            end = r.text.find('</script>', start)
            json_str = r.text[start:end].strip().rstrip(';')
            data = json.loads(json_str)
            
            def find_prods(d):
                if isinstance(d, dict):
                    if 'products' in d and isinstance(d['products'], list) and len(d['products']) > 0:
                        if isinstance(d['products'][0], dict):
                            return d['products']
                    for v in d.values():
                        res = find_prods(v)
                        if res:
                            return res
                elif isinstance(d, list):
                    for v in d:
                        res = find_prods(v)
                        if res:
                            return res
                return []
            
            prods = find_prods(data)
            for p in prods[:max_items]:
                brand = (p.get('brand') or {}).get('name', '') if isinstance(p.get('brand'), dict) else str(p.get('brand') or '')
                name = p.get('name', '')
                full_name = f"{brand} {name}".strip() or name
                
                prc_obj = p.get('price') or {}
                prc = prc_obj.get('discountedPrice') or prc_obj.get('sellingPrice') or prc_obj.get('current') or 0.0
                fiyat = _clean_price(prc)
                if fiyat <= 0:
                    continue
                
                eski_prc = prc_obj.get('originalPrice')
                eski_fiyat = _clean_price(eski_prc) if eski_prc else None
                
                p_url = p.get('url', '')
                full_url = f"https://www.trendyol.com{p_url}" if p_url.startswith('/') else p_url
                
                img_list = p.get('images', [])
                img_url = f"https://cdn.dsmcdn.com{img_list[0]}" if (img_list and isinstance(img_list[0], str)) else None
                
                merchant = (p.get('merchant') or {}).get('name') if isinstance(p.get('merchant'), dict) else None
                rating = (p.get('ratingScore') or {}).get('averageRating') if isinstance(p.get('ratingScore'), dict) else None
                review_count = (p.get('ratingScore') or {}).get('totalRatingCount') if isinstance(p.get('ratingScore'), dict) else None
                
                offers.append(RetailProductOffer(
                    platform=MarketPlatform.TRENDYOL,
                    platform_adi=meta["adi"],
                    platform_domain=meta["domain"],
                    platform_renk=meta["renk"],
                    urun_adi=full_name,
                    fiyat=fiyat,
                    eski_fiyat=eski_fiyat,
                    url=full_url,
                    gorsel_url=img_url,
                    satici=merchant,
                    stok_durumu=True,
                    puan=rating,
                    yorum_sayisi=review_count,
                ))
    except Exception as e:
        logger.warning(f"Trendyol scrape error for '{query}': {e}")
    return offers


def scrape_hepsiburada(query: str, max_items: int = 15) -> List[RetailProductOffer]:
    offers: List[RetailProductOffer] = []
    meta = PLATFORM_META[MarketPlatform.HEPSIBURADA]
    url = f"https://www.hepsiburada.com/ara?q={quote(query)}"
    try:
        r = requests.get(url, impersonate="chrome124", headers=DEFAULT_HEADERS, timeout=10)
        if r.status_code != 200:
            return offers
        
        soup = BeautifulSoup(r.text, 'html.parser')
        cards = soup.select('li[id^="i"], article[data-test-id="product-card-item"]')
        for c in cards[:max_items]:
            a = c.find('a', href=True)
            if not a:
                continue
            href = a['href']
            full_url = f"https://www.hepsiburada.com{href}" if not href.startswith('http') else href
            
            title = a.get('title')
            if not title:
                h3 = c.find('h3')
                title = h3.text.strip() if h3 else a.text.strip()
            
            price_el = c.select_one('[data-test-id^="final-price"], [class*="finalPrice"]')
            if not price_el:
                price_el = c.select_one('[data-test-id="price-current-price"]')
            
            fiyat = _clean_price(price_el.text) if price_el else 0.0
            if fiyat <= 0:
                continue
            
            img_el = c.find('img')
            img_url = (img_el.get('src') or img_el.get('data-src')) if img_el else None
            
            offers.append(RetailProductOffer(
                platform=MarketPlatform.HEPSIBURADA,
                platform_adi=meta["adi"],
                platform_domain=meta["domain"],
                platform_renk=meta["renk"],
                urun_adi=title,
                fiyat=fiyat,
                url=full_url,
                gorsel_url=img_url,
                stok_durumu=True,
            ))
    except Exception as e:
        logger.warning(f"Hepsiburada scrape error for '{query}': {e}")
    return offers


def scrape_dermoeczanem(query: str, max_items: int = 15) -> List[RetailProductOffer]:
    offers: List[RetailProductOffer] = []
    meta = PLATFORM_META[MarketPlatform.DERMOECZANEM]
    try:
        # Fast direct JSON endpoint
        api_url = f"https://www.dermoeczanem.com/srv/service/product/searchAll/{quote(query)}"
        r = requests.get(api_url, impersonate="chrome124", headers=DEFAULT_HEADERS, timeout=8)
        if r.status_code == 200:
            data = r.json()
            products = data.get('products', []) if isinstance(data, dict) else []
            for p in products[:max_items]:
                title = p.get('title', '').strip()
                if not title:
                    continue
                prc_raw = p.get('price_sell_with_vat') or p.get('price_sell') or 0.0
                fiyat = _clean_price(prc_raw)
                if fiyat <= 0:
                    continue
                old_raw = p.get('price_not_discounted')
                eski_fiyat = _clean_price(old_raw) if old_raw else None
                p_url = p.get('url', '')
                full_url = f"https://www.dermoeczanem.com/{p_url.lstrip('/')}"
                img_url = p.get('image')
                stock_val = p.get('stock', 1)
                stok_durumu = stock_val > 0 if isinstance(stock_val, (int, float)) else True
                
                offers.append(RetailProductOffer(
                    platform=MarketPlatform.DERMOECZANEM,
                    platform_adi=meta["adi"],
                    platform_domain=meta["domain"],
                    platform_renk=meta["renk"],
                    urun_adi=title,
                    fiyat=fiyat,
                    eski_fiyat=eski_fiyat,
                    url=full_url,
                    gorsel_url=img_url,
                    stok_durumu=stok_durumu,
                ))
            if offers:
                return offers
        
        # Fallback: HTML page search
        html_url = f"https://www.dermoeczanem.com/Arama?1&kelime={quote(query)}"
        r_html = requests.get(html_url, impersonate="chrome124", headers=DEFAULT_HEADERS, timeout=10)
        if r_html.status_code == 200:
            soup = BeautifulSoup(r_html.text, 'html.parser')
            for it in soup.select('.product-item')[:max_items]:
                a = it.find('a', href=True)
                if not a:
                    continue
                title = a.get('title') or a.text.strip()
                p_el = it.select_one('[class*="price"], [class*="fiyat"]')
                fiyat = _clean_price(p_el.text) if p_el else 0.0
                if fiyat <= 0:
                    continue
                full_url = f"https://www.dermoeczanem.com/{a['href'].lstrip('/')}"
                img_el = it.find('img')
                img_url = (img_el.get('src') or img_el.get('data-src')) if img_el else None
                offers.append(RetailProductOffer(
                    platform=MarketPlatform.DERMOECZANEM,
                    platform_adi=meta["adi"],
                    platform_domain=meta["domain"],
                    platform_renk=meta["renk"],
                    urun_adi=title,
                    fiyat=fiyat,
                    url=full_url,
                    gorsel_url=img_url,
                    stok_durumu=True,
                ))
    except Exception as e:
        logger.warning(f"Dermoeczanem scrape error for '{query}': {e}")
    return offers


def scrape_kirmizibeyaz(query: str, max_items: int = 15) -> List[RetailProductOffer]:
    offers: List[RetailProductOffer] = []
    meta = PLATFORM_META[MarketPlatform.KIRMIZIBEYAZ]
    try:
        # Fast direct JSON endpoint
        api_url = f"https://kirmizibeyazz.com/srv/service/product/searchAll/{quote(query)}"
        r = requests.get(api_url, impersonate="chrome124", headers=DEFAULT_HEADERS, timeout=8)
        if r.status_code == 200:
            data = r.json()
            products = data.get('products', []) if isinstance(data, dict) else []
            for p in products[:max_items]:
                title = p.get('title', '').strip()
                if not title:
                    continue
                prc_raw = p.get('price_sell_with_vat') or p.get('price_sell') or 0.0
                fiyat = _clean_price(prc_raw)
                if fiyat <= 0:
                    continue
                old_raw = p.get('price_not_discounted')
                eski_fiyat = _clean_price(old_raw) if old_raw else None
                p_url = p.get('url', '')
                full_url = f"https://kirmizibeyazz.com/{p_url.lstrip('/')}"
                img_url = p.get('image')
                stock_val = p.get('stock', 1)
                stok_durumu = stock_val > 0 if isinstance(stock_val, (int, float)) else True
                
                offers.append(RetailProductOffer(
                    platform=MarketPlatform.KIRMIZIBEYAZ,
                    platform_adi=meta["adi"],
                    platform_domain=meta["domain"],
                    platform_renk=meta["renk"],
                    urun_adi=title,
                    fiyat=fiyat,
                    eski_fiyat=eski_fiyat,
                    url=full_url,
                    gorsel_url=img_url,
                    stok_durumu=stok_durumu,
                ))
    except Exception as e:
        logger.warning(f"Kırmızıbeyaz scrape error for '{query}': {e}")
    return offers


def scrape_dermokozmetika(query: str, max_items: int = 15) -> List[RetailProductOffer]:
    offers: List[RetailProductOffer] = []
    meta = PLATFORM_META[MarketPlatform.DERMOKOZMETIKA]
    url = f"https://www.dermokozmetika.com.tr/arama?q={quote(query)}"
    try:
        r = requests.get(url, impersonate="chrome124", headers=DEFAULT_HEADERS, timeout=10)
        if r.status_code != 200:
            return offers
        soup = BeautifulSoup(r.text, 'html.parser')
        items = soup.select('.product-item')
        for it in items[:max_items]:
            img = it.select_one('img')
            title = img.get('alt', '').strip() if img else ''
            if not title:
                title_el = it.select_one('.product-title, .title')
                title = title_el.text.strip() if title_el else ''
            if not title:
                continue
            
            a = it.select_one('a[href]')
            href = a['href'] if a else ''
            full_url = f"https://www.dermokozmetika.com.tr{href}" if not href.startswith('http') else href
            
            price_el = it.select_one('.product-price, .price')
            fiyat = _clean_price(price_el.text) if price_el else 0.0
            if fiyat <= 0:
                continue
            
            img_url = (img.get('data-src') or img.get('src')) if img else None
            offers.append(RetailProductOffer(
                platform=MarketPlatform.DERMOKOZMETIKA,
                platform_adi=meta["adi"],
                platform_domain=meta["domain"],
                platform_renk=meta["renk"],
                urun_adi=title,
                fiyat=fiyat,
                url=full_url,
                gorsel_url=img_url,
                stok_durumu=True,
            ))
    except Exception as e:
        logger.warning(f"Dermokozmetika scrape error for '{query}': {e}")
    return offers


def scrape_daffne(query: str, max_items: int = 15) -> List[RetailProductOffer]:
    offers: List[RetailProductOffer] = []
    meta = PLATFORM_META[MarketPlatform.DAFFNE]
    url = f"https://www.daffne.com/arama?q={quote(query)}"
    try:
        r = requests.get(url, impersonate="chrome124", headers=DEFAULT_HEADERS, timeout=10)
        if r.status_code != 200:
            return offers
        soup = BeautifulSoup(r.text, 'html.parser')
        items = soup.select('.product-item')
        for it in items[:max_items]:
            title_el = it.select_one('.product-title, .title')
            title = title_el.text.strip() if title_el else ''
            if not title:
                img = it.select_one('img')
                title = img.get('alt', '').strip() if img else ''
            if not title:
                continue
            
            a = it.select_one('a[href]')
            href = a['href'] if a else ''
            full_url = f"https://www.daffne.com{href}" if not href.startswith('http') else href
            
            price_el = it.select_one('.product-price, .price')
            fiyat = _clean_price(price_el.text) if price_el else 0.0
            if fiyat <= 0:
                continue
            
            img = it.select_one('img')
            img_url = (img.get('data-src') or img.get('src')) if img else None
            offers.append(RetailProductOffer(
                platform=MarketPlatform.DAFFNE,
                platform_adi=meta["adi"],
                platform_domain=meta["domain"],
                platform_renk=meta["renk"],
                urun_adi=title,
                fiyat=fiyat,
                url=full_url,
                gorsel_url=img_url,
                stok_durumu=True,
            ))
    except Exception as e:
        logger.warning(f"Daffne scrape error for '{query}': {e}")
    return offers


def scrape_dermojet(query: str, max_items: int = 15) -> List[RetailProductOffer]:
    offers: List[RetailProductOffer] = []
    meta = PLATFORM_META[MarketPlatform.DERMOJET]
    url = f"https://www.dermojet.com.tr/Arama?1&kelime={quote(query)}"
    try:
        r = requests.get(url, impersonate="chrome124", headers=DEFAULT_HEADERS, timeout=10)
        if r.status_code != 200:
            return offers
        soup = BeautifulSoup(r.text, 'html.parser')
        items = soup.select('.productItem')
        for it in items[:max_items]:
            a = it.select_one('.productTitle a, a.productTitle, a[title]')
            title = a.get('title') if a and a.get('title') else (a.text.strip() if a else '')
            if not title:
                continue
            
            href = a['href'] if a else ''
            full_url = f"https://www.dermojet.com.tr{href}" if not href.startswith('http') else href
            
            price_el = it.select_one('.discountPrice span, .productPrice, .price')
            fiyat = _clean_price(price_el.text) if price_el else 0.0
            if fiyat <= 0:
                continue
            
            img = it.select_one('img')
            img_url = (img.get('data-src') or img.get('src')) if img else None
            offers.append(RetailProductOffer(
                platform=MarketPlatform.DERMOJET,
                platform_adi=meta["adi"],
                platform_domain=meta["domain"],
                platform_renk=meta["renk"],
                urun_adi=title,
                fiyat=fiyat,
                url=full_url,
                gorsel_url=img_url,
                stok_durumu=True,
            ))
    except Exception as e:
        logger.warning(f"Dermojet scrape error for '{query}': {e}")
    return offers


def scrape_kozvit(query: str, max_items: int = 15) -> List[RetailProductOffer]:
    offers: List[RetailProductOffer] = []
    meta = PLATFORM_META[MarketPlatform.KOZVIT]
    url = f"https://www.kozvit.com/search?s={quote(query)}"
    try:
        r = requests.get(url, impersonate="chrome124", headers=DEFAULT_HEADERS, timeout=10)
        if r.status_code != 200:
            return offers
        soup = BeautifulSoup(r.text, 'html.parser')
        items = soup.select('.product-item')
        for it in items[:max_items]:
            a = it.find('a', href=True)
            if not a:
                continue
            href = a['href']
            full_url = f"https://www.kozvit.com{href}" if not href.startswith('http') else href
            
            img = it.find('img')
            title = img.get('alt', '').strip() if img else ''
            if not title:
                strings = list(it.stripped_strings)
                if len(strings) > 1:
                    title = strings[1]
            if not title:
                continue
            
            fiyat = 0.0
            for s in it.stripped_strings:
                if 'TL' in s or '₺' in s:
                    fiyat = _clean_price(s)
                    if fiyat > 0:
                        break
            if fiyat <= 0:
                continue
            
            img_url = None
            if img:
                style = img.get('style', '')
                m_bg = re.search(r'url\("([^"]+)"\)', style)
                if m_bg:
                    img_url = m_bg.group(1)
                else:
                    img_url = img.get('src') or img.get('data-src')
            
            offers.append(RetailProductOffer(
                platform=MarketPlatform.KOZVIT,
                platform_adi=meta["adi"],
                platform_domain=meta["domain"],
                platform_renk=meta["renk"],
                urun_adi=title,
                fiyat=fiyat,
                url=full_url,
                gorsel_url=img_url,
                stok_durumu=True,
            ))
    except Exception as e:
        logger.warning(f"Kozvit scrape error for '{query}': {e}")
    return offers


def scrape_sachane(query: str, max_items: int = 15) -> List[RetailProductOffer]:
    offers: List[RetailProductOffer] = []
    meta = PLATFORM_META[MarketPlatform.SACHANE]
    url = f"https://sachane.com/arama?q={quote(query)}"
    try:
        r = requests.get(url, impersonate="chrome124", headers=DEFAULT_HEADERS, timeout=10)
        if r.status_code != 200:
            return offers
        soup = BeautifulSoup(r.text, 'html.parser')
        
        seen_urls = set()
        for a in soup.select('a[href*="-p-"]'):
            href = a.get('href', '').split('?')[0]
            if not href or href in seen_urls:
                continue
            
            p = a
            card = None
            for _ in range(5):
                if not p:
                    break
                p = p.parent
                if p and any('TL' in s for s in p.stripped_strings):
                    card = p
                    break
            
            if not card:
                continue
            seen_urls.add(href)
            
            title = a.text.strip()
            if not title:
                title_a = card.select_one('a[href*="-p-"]')
                title = title_a.text.strip() if title_a else ''
            if not title:
                continue
            
            fiyat = 0.0
            strings = list(card.stripped_strings)
            for i, s in enumerate(strings):
                if 'TL' in s or (i + 1 < len(strings) and 'TL' in strings[i + 1]):
                    p_val = _clean_price(s)
                    if p_val > 0:
                        fiyat = p_val
                        break
            if fiyat <= 0:
                continue
            
            img = card.select_one('img')
            img_url = (img.get('src') or img.get('data-src')) if img else None
            full_url = f"https://sachane.com/{href.lstrip('/')}"
            
            offers.append(RetailProductOffer(
                platform=MarketPlatform.SACHANE,
                platform_adi=meta["adi"],
                platform_domain=meta["domain"],
                platform_renk=meta["renk"],
                urun_adi=title,
                fiyat=fiyat,
                url=full_url,
                gorsel_url=img_url,
                stok_durumu=True,
            ))
            if len(offers) >= max_items:
                break
    except Exception as e:
        logger.warning(f"Sachane scrape error for '{query}': {e}")
    return offers


# ---------------------------------------------------------
# Retail Market Engine Class
# ---------------------------------------------------------

class RetailMarketEngine:
    """Tüm e-ticaret platformlarını ve depoları paralel sorgulayan ana motor."""

    def __init__(self, depo_motoru=None):
        self.depo_motoru = depo_motoru

    async def search_all_retail(self, query: str) -> List[RetailProductOffer]:
        """9 perakende platformunu eşzamanlı sorgular."""
        scrapers = [
            (MarketPlatform.TRENDYOL, scrape_trendyol),
            (MarketPlatform.HEPSIBURADA, scrape_hepsiburada),
            (MarketPlatform.DERMOECZANEM, scrape_dermoeczanem),
            (MarketPlatform.DERMOKOZMETIKA, scrape_dermokozmetika),
            (MarketPlatform.KIRMIZIBEYAZ, scrape_kirmizibeyaz),
            (MarketPlatform.DERMOJET, scrape_dermojet),
            (MarketPlatform.KOZVIT, scrape_kozvit),
            (MarketPlatform.DAFFNE, scrape_daffne),
            (MarketPlatform.SACHANE, scrape_sachane),
        ]
        
        tasks = [asyncio.to_thread(fn, query) for _, fn in scrapers]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        all_offers: List[RetailProductOffer] = []
        for i, res in enumerate(results):
            plat_name = scrapers[i][0].value
            if isinstance(res, Exception):
                logger.error(f"Platform {plat_name} failed: {res}")
            elif isinstance(res, list):
                all_offers.extend(res)
        
        # Fiyata göre sırala
        all_offers.sort(key=lambda x: x.fiyat)
        return all_offers

    async def get_depo_prices(self, query: str) -> Tuple[List[DepoOzetFiyat], Optional[float], Optional[str], Optional[str]]:
        """Mevcut DepoSorguMotoru üzerinden depo ve pazaryeri fiyatlarını çeker."""
        depo_fiyatlari: List[DepoOzetFiyat] = []
        en_dusuk_fiyat: Optional[float] = None
        en_dusuk_adi: Optional[str] = None
        catalog_name: Optional[str] = None
        
        if not self.depo_motoru:
            return depo_fiyatlari, en_dusuk_fiyat, en_dusuk_adi, catalog_name
        
        try:
            rapor = await self.depo_motoru.search_all(query)
            if rapor:
                catalog_name = getattr(rapor, 'urun_adi', None)
                if hasattr(rapor, 'sonuclar') and rapor.sonuclar:
                    for s in rapor.sonuclar:
                        # net_birim_maliyet_kdvli veya net_birim_maliyet
                        kdvli = getattr(s, 'net_birim_maliyet_kdvli', 0.0) or 0.0
                        kdvsiz = getattr(s, 'net_birim_maliyet', 0.0) or 0.0
                        if kdvli <= 0 and kdvsiz > 0:
                            kdvli = round(kdvsiz * 1.20, 2)
                        
                        stok_str = s.stok_durumu.value if hasattr(s.stok_durumu, 'value') else str(s.stok_durumu)
                        depo_kodu = s.depo.value if hasattr(s.depo, 'value') else str(s.depo)
                        
                        ozet = DepoOzetFiyat(
                            depo=depo_kodu,
                            depo_adi=getattr(s, 'depo_adi', depo_kodu),
                            net_birim_maliyet=round(kdvsiz, 2),
                            net_birim_maliyet_kdvli=round(kdvli, 2),
                            stok_durumu=stok_str,
                            stok_adedi=getattr(s, 'stok_adedi', None),
                            mf_metni=getattr(s, 'mf_metni', 'YOK') or 'YOK',
                            miad=getattr(s, 'miad', None),
                        )
                        depo_fiyatlari.append(ozet)
                        
                        if kdvli > 0 and (en_dusuk_fiyat is None or kdvli < en_dusuk_fiyat):
                            en_dusuk_fiyat = kdvli
                            en_dusuk_adi = ozet.depo_adi
                            
                # Eğer rapor doğrudan en_dusuk_maliyet_kdvli içeriyorsa
                if getattr(rapor, 'en_dusuk_maliyet_kdvli', None):
                    en_dusuk_fiyat = rapor.en_dusuk_maliyet_kdvli
                    if getattr(rapor, 'en_avantajli_depo', None):
                        en_dusuk_adi = rapor.en_avantajli_depo.value if hasattr(rapor.en_avantajli_depo, 'value') else str(rapor.en_avantajli_depo)
        except Exception as e:
            logger.error(f"Depo fiyatları alınırken hata: {e}")
            
        return depo_fiyatlari, en_dusuk_fiyat, en_dusuk_adi, catalog_name

    async def generate_market_report(self, query: str) -> MarketPriceReport:
        """Hem depoları hem de 9 internet platformunu paralel sorgulayarak tam kıyaslama raporu üretir."""
        query_clean = query.strip()
        is_barcode = bool(re.match(r'^\d{8,14}$', query_clean))

        # Katalogdan ürün adı ve tüm barkodları al
        from backend.catalog import catalog
        cat_info = catalog.get_by_barcode(query_clean) if is_barcode else None
        if not cat_info and not is_barcode:
            suggestions = catalog.search_suggestions(query_clean, limit=1)
            if suggestions:
                cat_info = catalog.get_by_barcode(suggestions[0]["barcode"])

        catalog_name = cat_info["name"] if cat_info else None
        primary_barcode = cat_info["barcode"] if cat_info else (query_clean if is_barcode else "")

        # 1. Depo sorgusu: Barkod üzerinden sorgula
        depo_target = primary_barcode if primary_barcode else query_clean
        depo_task = asyncio.create_task(self.get_depo_prices(depo_target))

        # 2. Perakende sorgusu: E-ticaret siteleri ürün adı ile arandığında çok daha zengin ve doğru sonuç verir
        if is_barcode and catalog_name:
            retail_search_term = clean_catalog_search_term(catalog_name)
        else:
            retail_search_term = query_clean

        retail_task = asyncio.create_task(self.search_all_retail(retail_search_term))

        retail_offers, (depo_fiyatlari, depo_en_dusuk, depo_en_dusuk_adi, dep_cat_name) = await asyncio.gather(
            retail_task, depo_task
        )
        if not catalog_name and dep_cat_name:
            catalog_name = dep_cat_name
            # Eğer başlangıçta barkod katalogda yoktu ama depodan isim geldiyse, pazaryerlerini bu isimle tara
            if is_barcode:
                retail_search_term = clean_catalog_search_term(catalog_name)
                retail_offers = await self.search_all_retail(retail_search_term)

        # Eğer barkod arandıysa ve ne katalog ne de depoda ürün bulunamadıysa, pazaryerlerinin rastgele ürünlerini temizle
        if is_barcode and not catalog_name:
            retail_offers = []

        search_target_name = catalog_name or (retail_offers[0].urun_adi if retail_offers else None)
        ref_name = search_target_name if search_target_name else query_clean
        
        # 3. Alakasız sonuçları ve sahte/anomali fiyatları ele (Relevance & Anomaly Filtering)
        filtered_offers: List[RetailProductOffer] = []
        for o in retail_offers:
            # Fiyat taban filtresi: 20 TL altı sahte, boş kutu, tester veya numune sachet'leri elenir
            if o.fiyat < 20.0:
                logger.info(f"Fiyat anomalisi (<20 TL): {o.urun_adi} -> {o.fiyat} TL ({o.platform_adi})")
                continue
            
            # Depo fiyatı varsa ve ürün > 40 TL ise, depo fiyatının %18'inin altındaki liste hataları elenir
            if depo_en_dusuk and depo_en_dusuk > 40.0 and o.fiyat < (depo_en_dusuk * 0.18):
                logger.info(f"Fiyat anomalisi (<%18 depo): {o.urun_adi} -> {o.fiyat} TL (Depo: {depo_en_dusuk}) ({o.platform_adi})")
                continue

            # Birebir ürün eşleşme kontrolü (Marka, Seri, Model, Ölçü, Paket Boyutu)
            ok, reason = is_strictly_relevant(o.urun_adi, ref_name)
            if ok:
                filtered_offers.append(o)
            else:
                logger.info(f"Uyuşmazlık nedeniyle elendi: '{o.urun_adi}' ({o.platform_adi}) -> {reason}")
        
        if filtered_offers:
            retail_offers = filtered_offers
        else:
            retail_offers = []

        # Fiyata göre sırala
        retail_offers.sort(key=lambda x: x.fiyat)
        
        # 4. İstatistikleri hesapla
        internet_en_dusuk = retail_offers[0].fiyat if retail_offers else None
        internet_en_dusuk_platform = retail_offers[0].platform_adi if retail_offers else None
        internet_en_yuksek = retail_offers[-1].fiyat if retail_offers else None
        internet_ortalama = round(sum(o.fiyat for o in retail_offers) / len(retail_offers), 2) if retail_offers else None
        
        # 5. Arbitraj & Kâr hesaplaması
        kar_farki_tl = None
        kar_yuzdesi = None
        internet_depodan_ucuz = False
        
        if internet_en_dusuk is not None and depo_en_dusuk is not None:
            kar_farki_tl = round(internet_en_dusuk - depo_en_dusuk, 2)
            if depo_en_dusuk > 0:
                kar_yuzdesi = round(((internet_en_dusuk - depo_en_dusuk) / depo_en_dusuk) * 100, 1)
            if internet_en_dusuk < depo_en_dusuk:
                internet_depodan_ucuz = True
        
        platforms_found = len({o.platform for o in retail_offers})
        urun_adi = search_target_name or (retail_offers[0].urun_adi if retail_offers else query_clean)
        
        return MarketPriceReport(
            aranan_kelime=query_clean,
            barkod=query_clean if is_barcode else None,
            urun_adi=urun_adi,
            depo_en_dusuk_fiyat=depo_en_dusuk,
            depo_en_dusuk_adi=depo_en_dusuk_adi,
            depo_fiyatlari=depo_fiyatlari,
            internet_en_dusuk_fiyat=internet_en_dusuk,
            internet_en_dusuk_platform=internet_en_dusuk_platform,
            internet_en_yuksek_fiyat=internet_en_yuksek,
            internet_ortalama_fiyat=internet_ortalama,
            kar_farki_tl=kar_farki_tl,
            kar_yuzdesi=kar_yuzdesi,
            internet_depodan_ucuz=internet_depodan_ucuz,
            teklifler=retail_offers,
            platform_sayisi=platforms_found,
            toplam_teklif_sayisi=len(retail_offers),
        )
